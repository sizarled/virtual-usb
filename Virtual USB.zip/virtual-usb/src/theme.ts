export type ThemeMode = 'system' | 'light' | 'dark';

export type Palette = {
  isDark: boolean;
  bg: string;
  bgAlt: string;
  surface: string;
  surfaceAlt: string;
  border: string;
  divider: string;
  text: string;
  textDim: string;
  textFaint: string;
  accent: string;
  accentSoft: string;
  accentContrast: string;
  danger: string;
  dangerSoft: string;
  success: string;
  warning: string;
  overlay: string;
  sheet: string;
  chip: string;
  chipActive: string;
  folder: string;
  skeleton: string;
};

const dark: Palette = {
  isDark: true,
  bg: '#0B0E14',
  bgAlt: '#0F131C',
  surface: '#151A24',
  surfaceAlt: '#1B2230',
  border: '#242C3B',
  divider: '#1E2532',
  text: '#E8ECF4',
  textDim: '#9AA6BC',
  textFaint: '#6B7789',
  accent: '#4C8DFF',
  accentSoft: 'rgba(76, 141, 255, 0.16)',
  accentContrast: '#FFFFFF',
  danger: '#FF5C6C',
  dangerSoft: 'rgba(255, 92, 108, 0.15)',
  success: '#2DD4A7',
  warning: '#FFB547',
  overlay: 'rgba(4, 6, 10, 0.72)',
  sheet: '#121722',
  chip: '#1A2130',
  chipActive: '#24304A',
  folder: '#FFC861',
  skeleton: '#1A2130',
};

const light: Palette = {
  isDark: false,
  bg: '#F4F6FB',
  bgAlt: '#FFFFFF',
  surface: '#FFFFFF',
  surfaceAlt: '#F0F3F9',
  border: '#E1E6F0',
  divider: '#E7EBF3',
  text: '#111725',
  textDim: '#5A6579',
  textFaint: '#8A94A6',
  accent: '#2563EB',
  accentSoft: 'rgba(37, 99, 235, 0.12)',
  accentContrast: '#FFFFFF',
  danger: '#DC2626',
  dangerSoft: 'rgba(220, 38, 38, 0.12)',
  success: '#0E9F6E',
  warning: '#B45309',
  overlay: 'rgba(15, 23, 42, 0.45)',
  sheet: '#FFFFFF',
  chip: '#EDF1F8',
  chipActive: '#DCE6FF',
  folder: '#E0A02B',
  skeleton: '#E6EAF2',
};

export const palettes: Record<'dark' | 'light', Palette> = { dark, light };

export type Spacing = { xs: number; sm: number; md: number; lg: number; xl: number };

export const SP: Spacing = { xs: 4, sm: 8, md: 12, lg: 16, xl: 24 };

export const RADIUS = { sm: 8, md: 12, lg: 16, xl: 22, pill: 999 };

import React, { useEffect, useState } from 'react';
import { ActivityIndicator, StyleSheet, Text, TextInput, View } from 'react-native';

import { useApp } from '../state/AppContext';
import { RADIUS, SP } from '../theme';
import { ActionList, Sheet, SheetAction, SheetButton } from './Sheet';

/* ---------------------------------- Confirm --------------------------------- */

export function ConfirmDialog({
  visible,
  title,
  message,
  confirmLabel,
  danger,
  loading,
  onConfirm,
  onCancel,
}: {
  visible: boolean;
  title: string;
  message?: string;
  confirmLabel: string;
  danger?: boolean;
  loading?: boolean;
  onConfirm: () => void;
  onCancel: () => void;
}) {
  const { palette, t, isRTL } = useApp();
  return (
    <Sheet visible={visible} onClose={onCancel} align="center" title={title}>
      <View style={{ paddingHorizontal: SP.xl }}>
        {message ? (
          <Text style={[styles.message, { color: palette.textDim, textAlign: isRTL ? 'right' : 'left' }]}>
            {message}
          </Text>
        ) : null}
        <SheetButton
          label={loading ? t('loading') : confirmLabel}
          onPress={onConfirm}
          variant={danger ? 'danger' : 'primary'}
          disabled={loading}
        />
        <SheetButton label={t('cancel')} onPress={onCancel} variant="ghost" />
      </View>
    </Sheet>
  );
}

/* ---------------------------------- Prompt ---------------------------------- */

export function PromptDialog({
  visible,
  title,
  placeholder,
  initialValue = '',
  confirmLabel,
  onSubmit,
  onCancel,
}: {
  visible: boolean;
  title: string;
  placeholder?: string;
  initialValue?: string;
  confirmLabel: string;
  onSubmit: (value: string) => void;
  onCancel: () => void;
}) {
  const { t } = useApp();
  const [value, setValue] = useState(initialValue);

  useEffect(() => {
    if (visible) setValue(initialValue);
  }, [visible, initialValue]);

  return (
    <Sheet visible={visible} onClose={onCancel} align="center" title={title}>
      <View style={{ paddingHorizontal: SP.xl }}>
        <TextInputBox
          value={value}
          onChangeText={setValue}
          placeholder={placeholder}
          autoFocus
          onSubmit={() => onSubmit(value)}
        />
        <SheetButton
          label={confirmLabel}
          onPress={() => onSubmit(value)}
          disabled={!value.trim()}
        />
        <SheetButton label={t('cancel')} onPress={onCancel} variant="ghost" />
      </View>
    </Sheet>
  );
}

export function TextInputBox({
  value,
  onChangeText,
  placeholder,
  autoFocus,
  onSubmit,
  mono,
  multiline,
}: {
  value: string;
  onChangeText: (v: string) => void;
  placeholder?: string;
  autoFocus?: boolean;
  onSubmit?: () => void;
  mono?: boolean;
  multiline?: boolean;
}) {
  const { palette, isRTL } = useApp();
  return (
    <View
      style={[
        styles.inputWrap,
        { backgroundColor: palette.surfaceAlt, borderColor: palette.border, flexDirection: isRTL ? 'row-reverse' : 'row' },
      ]}
    >
      <TextInput
        value={value}
        onChangeText={onChangeText}
        placeholder={placeholder}
        placeholderTextColor={palette.textFaint}
        autoFocus={autoFocus}
        onSubmitEditing={onSubmit}
        multiline={multiline}
        style={[
          styles.input,
          {
            color: palette.text,
            textAlign: isRTL ? 'right' : 'left',
            fontFamily: mono ? 'Menlo' : undefined,
          },
        ]}
      />
    </View>
  );
}

/* --------------------------------- Action menu ------------------------------- */

export function ActionMenuDialog({
  visible,
  title,
  subtitle,
  actions,
  onClose,
}: {
  visible: boolean;
  title: string;
  subtitle?: string;
  actions: SheetAction[];
  onClose: () => void;
}) {
  return (
    <Sheet visible={visible} onClose={onClose} title={title} subtitle={subtitle}>
      <ActionList actions={actions} />
    </Sheet>
  );
}

/* -------------------------------- Busy overlay ------------------------------- */

export function BusyOverlay() {
  const { palette, busy, t } = useApp();
  if (!busy) return null;
  const { label, done, total } = busy;
  const hasProgress = typeof done === 'number' && typeof total === 'number' && total > 0;
  const ratio = hasProgress ? Math.min(1, (done as number) / (total as number)) : 0;
  return (
    <View style={[styles.overlayRoot, { backgroundColor: palette.overlay }]} pointerEvents="auto">
      <View style={[styles.busyCard, { backgroundColor: palette.surface, borderColor: palette.border }]}>
        <ActivityIndicator size="large" color={palette.accent} />
        <Text style={[styles.busyLabel, { color: palette.text }]}>{label}</Text>
        {hasProgress ? (
          <>
            <View style={[styles.progressTrack, { backgroundColor: palette.surfaceAlt }]}>
              <View
                style={[styles.progressFill, { backgroundColor: palette.accent, width: `${ratio * 100}%` }]}
              />
            </View>
            <Text style={[styles.busyMeta, { color: palette.textDim }]}>
              {t('workingProgress', { done: done as number, total: total as number })}
            </Text>
          </>
        ) : null}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  message: { fontSize: 14, lineHeight: 21, marginBottom: SP.md },
  inputWrap: {
    borderWidth: 1,
    borderRadius: RADIUS.md,
    paddingHorizontal: SP.md,
    paddingVertical: SP.sm,
    alignItems: 'center',
  },
  input: { flex: 1, fontSize: 16, paddingVertical: 4, minHeight: 24 },
  overlayRoot: {
    ...StyleSheet.absoluteFillObject,
    alignItems: 'center',
    justifyContent: 'center',
    zIndex: 50,
    elevation: 20,
  },
  busyCard: {
    width: '72%',
    borderRadius: RADIUS.lg,
    borderWidth: 1,
    padding: SP.xl,
    alignItems: 'center',
    gap: SP.md,
  },
  busyLabel: { fontSize: 15, fontWeight: '700', textAlign: 'center' },
  busyMeta: { fontSize: 12 },
  progressTrack: { width: '100%', height: 6, borderRadius: 3, overflow: 'hidden' },
  progressFill: { height: 6, borderRadius: 3 },
});

import { Ionicons } from '@expo/vector-icons';
import React from 'react';
import { StyleSheet, Text, TouchableOpacity, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import { useApp } from '../state/AppContext';
import { RADIUS, SP } from '../theme';

export function ToastView() {
  const { toast, palette, hideToast, isRTL } = useApp();
  const insets = useSafeAreaInsets();
  if (!toast) return null;

  const color =
    toast.kind === 'error' ? palette.danger : toast.kind === 'success' ? palette.success : palette.accent;
  const icon: React.ComponentProps<typeof Ionicons>['name'] =
    toast.kind === 'error'
      ? 'alert-circle'
      : toast.kind === 'success'
        ? 'checkmark-circle'
        : 'information-circle';

  return (
    <View style={[styles.toastWrap, { bottom: insets.bottom + 96 }]} pointerEvents="box-none">
      <TouchableOpacity
        activeOpacity={0.9}
        onPress={hideToast}
        style={[
          styles.toast,
          {
            backgroundColor: palette.surface,
            borderColor: palette.border,
            flexDirection: isRTL ? 'row-reverse' : 'row',
          },
        ]}
      >
        <Ionicons name={icon} size={18} color={color} />
        <Text style={[styles.toastText, { color: palette.text, textAlign: isRTL ? 'right' : 'left' }]}>
          {toast.message}
        </Text>
      </TouchableOpacity>
    </View>
  );
}

export function EmptyView({
  icon,
  title,
  hint,
  actionLabel,
  onAction,
}: {
  icon: React.ComponentProps<typeof Ionicons>['name'];
  title: string;
  hint?: string;
  actionLabel?: string;
  onAction?: () => void;
}) {
  const { palette, isRTL } = useApp();
  return (
    <View style={styles.empty}>
      <View style={[styles.emptyIcon, { backgroundColor: palette.surfaceAlt }]}>
        <Ionicons name={icon} size={30} color={palette.textFaint} />
      </View>
      <Text style={[styles.emptyTitle, { color: palette.text, textAlign: isRTL ? 'right' : 'left' }]}>
        {title}
      </Text>
      {hint ? (
        <Text style={[styles.emptyHint, { color: palette.textDim, textAlign: 'center' }]}>{hint}</Text>
      ) : null}
      {actionLabel && onAction ? (
        <TouchableOpacity style={[styles.emptyBtn, { backgroundColor: palette.accent }]} onPress={onAction}>
          <Text style={[styles.emptyBtnLabel, { color: palette.accentContrast }]}>{actionLabel}</Text>
        </TouchableOpacity>
      ) : null}
    </View>
  );
}

const styles = StyleSheet.create({
  toastWrap: { position: 'absolute', left: SP.lg, right: SP.lg, alignItems: 'center', zIndex: 60 },
  toast: {
    alignItems: 'center',
    gap: SP.sm,
    paddingVertical: 11,
    paddingHorizontal: SP.lg,
    borderRadius: RADIUS.pill,
    borderWidth: 1,
    shadowOpacity: 0.25,
    shadowRadius: 12,
    shadowOffset: { width: 0, height: 4 },
    elevation: 8,
    maxWidth: '100%',
  },
  toastText: { flexShrink: 1, fontSize: 13, fontWeight: '600' },
  empty: { flex: 1, alignItems: 'center', justifyContent: 'center', padding: SP.xl * 1.5, gap: SP.md },
  emptyIcon: { width: 66, height: 66, borderRadius: 33, alignItems: 'center', justifyContent: 'center' },
  emptyTitle: { fontSize: 16, fontWeight: '700', textAlign: 'center' },
  emptyHint: { fontSize: 13, lineHeight: 20 },
  emptyBtn: { marginTop: SP.sm, paddingHorizontal: SP.xl, paddingVertical: 11, borderRadius: RADIUS.pill },
  emptyBtnLabel: { fontSize: 14, fontWeight: '700' },
});

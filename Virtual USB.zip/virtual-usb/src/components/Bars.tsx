import { Ionicons } from '@expo/vector-icons';
import React from 'react';
import { ScrollView, StyleSheet, Text, TouchableOpacity, View } from 'react-native';

import { Category, categoryLabel } from '../lib/categories';
import { useApp } from '../state/AppContext';
import { RADIUS, SP } from '../theme';

/* ------------------------------ Category chips ------------------------------ */

export function CategoryBar({
  categories,
  counts,
  active,
  total,
  onChange,
}: {
  categories: Category[];
  counts: Record<string, number>;
  active: string;
  total: number;
  onChange: (id: string) => void;
}) {
  const { palette, isRTL, t, lang } = useApp();

  const chips: { id: string; label: string; icon: React.ComponentProps<typeof Ionicons>['name']; color: string; count: number }[] = [
    {
      id: 'all',
      label: t('all'),
      icon: 'layers',
      color: palette.accent,
      count: total,
    },
    ...categories.map((c) => ({
      id: c.id,
      label: categoryLabel(c, lang),
      icon: c.icon as React.ComponentProps<typeof Ionicons>['name'],
      color: c.color,
      count: counts[c.id] ?? 0,
    })),
  ];

  return (
    <ScrollView
      horizontal
      showsHorizontalScrollIndicator={false}
      contentContainerStyle={[styles.chips, { flexDirection: isRTL ? 'row-reverse' : 'row' }]}
      style={styles.chipsScroll}
    >
      {chips.map((chip) => {
        const isActive = chip.id === active;
        return (
          <TouchableOpacity
            key={chip.id}
            onPress={() => onChange(chip.id)}
            style={[
              styles.chip,
              {
                flexDirection: isRTL ? 'row-reverse' : 'row',
                backgroundColor: isActive ? chip.color : palette.chip,
                borderColor: isActive ? chip.color : palette.border,
              },
            ]}
          >
            <Ionicons
              name={chip.icon}
              size={15}
              color={isActive ? '#FFFFFF' : chip.color}
            />
            <Text style={[styles.chipLabel, { color: isActive ? '#FFFFFF' : palette.text }]}>
              {chip.label}
            </Text>
            <View
              style={[
                styles.chipCount,
                { backgroundColor: isActive ? 'rgba(255,255,255,0.25)' : palette.surfaceAlt },
              ]}
            >
              <Text style={[styles.chipCountText, { color: isActive ? '#FFFFFF' : palette.textDim }]}>
                {chip.count}
              </Text>
            </View>
          </TouchableOpacity>
        );
      })}
    </ScrollView>
  );
}

/* -------------------------------- Breadcrumb -------------------------------- */

export function PathBar({
  crumbs,
  onNavigate,
  canGoUp,
  onGoUp,
}: {
  crumbs: { path: string; name: string }[];
  onNavigate: (target: string) => void;
  canGoUp: boolean;
  onGoUp: () => void;
}) {
  const { palette, isRTL } = useApp();

  return (
    <View style={[styles.pathBar, { borderBottomColor: palette.divider }]}>
      <ScrollView
        horizontal
        showsHorizontalScrollIndicator={false}
        contentContainerStyle={[styles.pathContent, { flexDirection: isRTL ? 'row-reverse' : 'row' }]}
      >
        {crumbs.map((crumb, index) => {
          const isLast = index === crumbs.length - 1;
          return (
            <TouchableOpacity
              key={crumb.path + index}
              style={[styles.crumb, { flexDirection: isRTL ? 'row-reverse' : 'row' }]}
              onPress={() => onNavigate(crumb.path)}
              disabled={isLast}
            >
              {index > 0 ? (
                <Ionicons
                  name={isRTL ? 'chevron-back' : 'chevron-forward'}
                  size={13}
                  color={palette.textFaint}
                />
              ) : null}
              <Text
                numberOfLines={1}
                style={[
                  styles.crumbText,
                  { color: isLast ? palette.text : palette.textDim, fontWeight: isLast ? '700' : '500' },
                ]}
              >
                {crumb.name}
              </Text>
            </TouchableOpacity>
          );
        })}
      </ScrollView>
      <TouchableOpacity onPress={onGoUp} disabled={!canGoUp} style={styles.upBtn}>
        <Ionicons name="arrow-up" size={18} color={!canGoUp ? palette.textFaint : palette.text} />
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  chipsScroll: { flexGrow: 0 },
  chips: { gap: SP.sm, paddingHorizontal: SP.lg, paddingVertical: SP.sm },
  chip: {
    alignItems: 'center',
    paddingHorizontal: SP.md,
    paddingVertical: 7,
    borderRadius: RADIUS.pill,
    borderWidth: 1,
    gap: 6,
  },
  chipLabel: { fontSize: 13, fontWeight: '600' },
  chipCount: { paddingHorizontal: 6, paddingVertical: 1, borderRadius: RADIUS.pill },
  chipCountText: { fontSize: 11, fontWeight: '700' },
  pathBar: {
    flexDirection: 'row',
    alignItems: 'center',
    borderBottomWidth: StyleSheet.hairlineWidth,
    paddingLeft: SP.md,
    paddingRight: SP.xs,
  },
  pathContent: { alignItems: 'center', gap: 2, paddingVertical: 9, flexGrow: 1 },
  crumb: { alignItems: 'center', gap: 2 },
  crumbText: { fontSize: 13 },
  upBtn: { padding: SP.sm },
});

import { Ionicons } from '@expo/vector-icons';
import React, { useEffect, useState } from 'react';
import { Image, StyleSheet, Text, TouchableOpacity, View } from 'react-native';

import { Category, categoryLabel } from '../lib/categories';
import { formatBytes, formatRelative } from '../lib/format';
import { FsItem } from '../lib/fs';
import { fileUri } from '../lib/paths';
import { useApp } from '../state/AppContext';
import { RADIUS, SP } from '../theme';

const THUMBNAIL_EXTS = new Set([
  'jpg', 'jpeg', 'png', 'gif', 'webp', 'heic', 'heif', 'bmp', 'tif', 'tiff', 'ico',
]);

export function ItemIcon({
  item,
  category,
  size = 46,
}: {
  item: FsItem;
  category: Category;
  size?: number;
}) {
  const { palette } = useApp();
  const [thumbFailed, setThumbFailed] = useState(false);
  useEffect(() => setThumbFailed(false), [item.path]);

  const useThumb = !item.isDir && THUMBNAIL_EXTS.has(item.ext) && !thumbFailed;

  if (useThumb) {
    return (
      <View
        style={[
          styles.iconBox,
          {
            width: size,
            height: size,
            borderRadius: RADIUS.md,
            backgroundColor: palette.surfaceAlt,
            overflow: 'hidden',
          },
        ]}
      >
        <Image
          source={{ uri: fileUri(item.path) }}
          style={{ width: size, height: size }}
          resizeMode="cover"
          onError={() => setThumbFailed(true)}
        />
      </View>
    );
  }

  const color = item.isDir ? palette.folder : category.color;
  return (
    <View
      style={[
        styles.iconBox,
        {
          width: size,
          height: size,
          borderRadius: RADIUS.md,
          backgroundColor: item.isDir ? 'rgba(255, 200, 97, 0.14)' : `${category.color}22`,
        },
      ]}
    >
      <Ionicons
        name={(item.isDir ? 'folder' : category.icon) as React.ComponentProps<typeof Ionicons>['name']}
        size={Math.round(size * 0.52)}
        color={color}
      />
    </View>
  );
}

export function ItemRow({
  item,
  category,
  selected,
  selectionMode,
  subtitle,
  onPress,
  onLongPress,
  onMore,
}: {
  item: FsItem;
  category: Category;
  selected?: boolean;
  selectionMode?: boolean;
  subtitle?: string;
  onPress: () => void;
  onLongPress: () => void;
  onMore: () => void;
}) {
  const { palette, isRTL, t, lang } = useApp();

  const meta = item.isDir
    ? [t('folderLabel'), item.mtime ? formatRelative(item.mtime, lang) : null]
        .filter(Boolean)
        .join(' · ')
    : [
        formatBytes(item.size),
        item.ext ? item.ext.toUpperCase() : t('fileLabel'),
        item.mtime ? formatRelative(item.mtime, lang) : null,
      ]
        .filter(Boolean)
        .join(' · ');

  return (
    <TouchableOpacity
      style={[
        styles.row,
        {
          flexDirection: isRTL ? 'row-reverse' : 'row',
          backgroundColor: selected ? palette.accentSoft : 'transparent',
          borderBottomColor: palette.divider,
        },
      ]}
      onPress={onPress}
      onLongPress={onLongPress}
      delayLongPress={350}
      activeOpacity={0.7}
    >
      <ItemIcon item={item} category={category} />

      <View style={styles.content}>
        <Text
          numberOfLines={2}
          style={[styles.name, { color: palette.text, textAlign: isRTL ? 'right' : 'left' }]}
        >
          {item.name}
        </Text>
        <Text numberOfLines={1} style={[styles.meta, { color: palette.textDim, textAlign: isRTL ? 'right' : 'left' }]}>
          {subtitle ? `${subtitle} · ` : ''}
          {meta}
        </Text>
        {!item.isDir ? (
          <View style={[styles.badgeRow, { flexDirection: isRTL ? 'row-reverse' : 'row' }]}>
            <View style={[styles.dot, { backgroundColor: category.color }]} />
            <Text style={[styles.badge, { color: palette.textFaint }]}>
              {categoryLabel(category, lang)}
            </Text>
          </View>
        ) : null}
      </View>

      {selectionMode ? (
        <View style={[styles.check, { borderColor: selected ? palette.accent : palette.border }]}>
          {selected ? <Ionicons name="checkmark" size={16} color={palette.accentContrast} /> : null}
          {selected ? <View style={[styles.checkFill, { backgroundColor: palette.accent }]} /> : null}
        </View>
      ) : (
        <TouchableOpacity onPress={onMore} hitSlop={10} style={styles.moreBtn}>
          <Ionicons name="ellipsis-vertical" size={18} color={palette.textFaint} />
        </TouchableOpacity>
      )}
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  iconBox: { alignItems: 'center', justifyContent: 'center' },
  row: {
    alignItems: 'center',
    paddingVertical: SP.md - 2,
    paddingHorizontal: SP.lg,
    borderBottomWidth: StyleSheet.hairlineWidth,
    gap: SP.md,
  },
  content: { flex: 1, gap: 2 },
  name: { fontSize: 15, fontWeight: '600' },
  meta: { fontSize: 12 },
  badgeRow: { alignItems: 'center', gap: 5, marginTop: 2 },
  dot: { width: 6, height: 6, borderRadius: 3 },
  badge: { fontSize: 11 },
  check: {
    width: 24,
    height: 24,
    borderRadius: 12,
    borderWidth: 1.5,
    alignItems: 'center',
    justifyContent: 'center',
    overflow: 'hidden',
  },
  checkFill: { ...StyleSheet.absoluteFillObject },
  moreBtn: { padding: SP.xs },
});

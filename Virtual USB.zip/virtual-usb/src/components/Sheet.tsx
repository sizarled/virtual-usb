import { Ionicons } from '@expo/vector-icons';
import React from 'react';
import {
  Modal,
  Pressable,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
  useWindowDimensions,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import { useApp } from '../state/AppContext';
import { RADIUS, SP } from '../theme';

type SheetProps = {
  visible: boolean;
  onClose: () => void;
  title?: string;
  subtitle?: string;
  children?: React.ReactNode;
  /** Render instead of the default bottom sheet (e.g. centered dialog) */
  align?: 'bottom' | 'center';
};

export function Sheet({
  visible,
  onClose,
  title,
  subtitle,
  children,
  align = 'bottom',
}: SheetProps) {
  const { palette, isRTL } = useApp();
  const insets = useSafeAreaInsets();
  const { height } = useWindowDimensions();

  return (
    <Modal
      visible={visible}
      transparent
      animationType={align === 'bottom' ? 'slide' : 'fade'}
      onRequestClose={onClose}
      statusBarTranslucent
    >
      <View style={[styles.root, align === 'center' && styles.rootCentered]}>
        <Pressable style={styles.backdrop} onPress={onClose} />
        <View
          style={[
            styles.sheet,
            {
              backgroundColor: palette.sheet,
              paddingBottom: insets.bottom + SP.lg,
              maxHeight: height * 0.88,
            },
            align === 'center' && styles.sheetCentered,
          ]}
        >
          <View style={[styles.grabber, { backgroundColor: palette.border }]} />
          {(title || subtitle) && (
            <View style={[styles.header, { flexDirection: isRTL ? 'row-reverse' : 'row' }]}>
              <View style={{ flex: 1 }}>
                {title ? (
                  <Text
                    style={[styles.title, { color: palette.text, textAlign: isRTL ? 'right' : 'left' }]}
                  >
                    {title}
                  </Text>
                ) : null}
                {subtitle ? (
                  <Text
                    style={[
                      styles.subtitle,
                      { color: palette.textDim, textAlign: isRTL ? 'right' : 'left' },
                    ]}
                  >
                    {subtitle}
                  </Text>
                ) : null}
              </View>
              <TouchableOpacity onPress={onClose} style={[styles.closeBtn, { backgroundColor: palette.surfaceAlt }]}>
                <Ionicons name="close" size={18} color={palette.textDim} />
              </TouchableOpacity>
            </View>
          )}
          {children}
        </View>
      </View>
    </Modal>
  );
}

export type SheetAction = {
  key: string;
  label: string;
  icon: React.ComponentProps<typeof Ionicons>['name'];
  danger?: boolean;
  disabled?: boolean;
  hint?: string;
  onPress: () => void;
};

export function ActionList({ actions }: { actions: SheetAction[] }) {
  const { palette, isRTL } = useApp();
  return (
    <View style={{ paddingHorizontal: SP.lg, paddingBottom: SP.sm }}>
      {actions
        .filter((a) => !a.disabled)
        .map((action) => (
          <TouchableOpacity
            key={action.key}
            style={[
              styles.actionRow,
              { flexDirection: isRTL ? 'row-reverse' : 'row', borderBottomColor: palette.divider },
            ]}
            onPress={action.onPress}
          >
            <View
              style={[
                styles.actionIcon,
                { backgroundColor: action.danger ? palette.dangerSoft : palette.surfaceAlt },
              ]}
            >
              <Ionicons
                name={action.icon}
                size={18}
                color={action.danger ? palette.danger : palette.text}
              />
            </View>
            <View style={{ flex: 1 }}>
              <Text
                style={[
                  styles.actionLabel,
                  { color: action.danger ? palette.danger : palette.text, textAlign: isRTL ? 'right' : 'left' },
                ]}
              >
                {action.label}
              </Text>
              {action.hint ? (
                <Text style={[styles.actionHint, { color: palette.textFaint, textAlign: isRTL ? 'right' : 'left' }]}>
                  {action.hint}
                </Text>
              ) : null}
            </View>
            <Ionicons
              name={isRTL ? 'chevron-back' : 'chevron-forward'}
              size={16}
              color={palette.textFaint}
            />
          </TouchableOpacity>
        ))}
    </View>
  );
}

export function SheetButton({
  label,
  onPress,
  variant = 'primary',
  icon,
  disabled,
}: {
  label: string;
  onPress: () => void;
  variant?: 'primary' | 'ghost' | 'danger';
  icon?: React.ComponentProps<typeof Ionicons>['name'];
  disabled?: boolean;
}) {
  const { palette, isRTL } = useApp();
  const bg =
    variant === 'primary' ? palette.accent : variant === 'danger' ? palette.danger : palette.surfaceAlt;
  const fg = variant === 'ghost' ? palette.text : palette.accentContrast;
  return (
    <TouchableOpacity
      disabled={disabled}
      onPress={onPress}
      style={[
        styles.button,
        { backgroundColor: bg, opacity: disabled ? 0.5 : 1, flexDirection: isRTL ? 'row-reverse' : 'row' },
      ]}
    >
      {icon ? <Ionicons name={icon} size={18} color={fg} /> : null}
      <Text style={[styles.buttonLabel, { color: fg }]}>{label}</Text>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, justifyContent: 'flex-end' },
  rootCentered: { justifyContent: 'center', paddingHorizontal: SP.xl },
  backdrop: { ...StyleSheet.absoluteFillObject, backgroundColor: 'rgba(0,0,0,0.55)' },
  sheet: {
    borderTopLeftRadius: RADIUS.xl,
    borderTopRightRadius: RADIUS.xl,
    paddingTop: SP.sm,
  },
  sheetCentered: { borderRadius: RADIUS.xl, paddingTop: SP.lg },
  grabber: {
    alignSelf: 'center',
    width: 42,
    height: 4,
    borderRadius: 2,
    marginBottom: SP.md,
  },
  header: { alignItems: 'center', paddingHorizontal: SP.lg, marginBottom: SP.md, gap: SP.sm },
  title: { fontSize: 18, fontWeight: '700' },
  subtitle: { fontSize: 13, marginTop: 2, lineHeight: 18 },
  closeBtn: { width: 30, height: 30, borderRadius: 15, alignItems: 'center', justifyContent: 'center' },
  actionRow: {
    alignItems: 'center',
    paddingVertical: SP.md - 2,
    borderBottomWidth: StyleSheet.hairlineWidth,
    gap: SP.md,
  },
  actionIcon: { width: 34, height: 34, borderRadius: 10, alignItems: 'center', justifyContent: 'center' },
  actionLabel: { fontSize: 15, fontWeight: '600' },
  actionHint: { fontSize: 11, marginTop: 2 },
  button: {
    height: 48,
    borderRadius: RADIUS.md,
    alignItems: 'center',
    justifyContent: 'center',
    gap: SP.sm,
    marginTop: SP.md,
  },
  buttonLabel: { fontSize: 16, fontWeight: '700' },
});

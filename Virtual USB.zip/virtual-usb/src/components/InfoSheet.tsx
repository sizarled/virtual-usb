import { Ionicons } from '@expo/vector-icons';
import { File } from 'expo-file-system';
import React, { useEffect, useState } from 'react';
import { ActivityIndicator, ScrollView, StyleSheet, Text, TouchableOpacity, View } from 'react-native';

import { Category, categoryLabel } from '../lib/categories';
import { formatBytes, formatDateTime } from '../lib/format';
import { details, dirSize, FileDetails, FsItem } from '../lib/fs';
import { fileUri } from '../lib/paths';
import { useApp } from '../state/AppContext';
import { RADIUS, SP } from '../theme';
import { Sheet } from './Sheet';

export function InfoSheet({
  visible,
  item,
  category,
  onClose,
  onShare,
}: {
  visible: boolean;
  item: FsItem | null;
  category: Category | null;
  onClose: () => void;
  onShare?: () => void;
}) {
  const { palette, t, lang, isRTL } = useApp();
  const [info, setInfo] = useState<FileDetails | null>(null);
  const [folderStats, setFolderStats] = useState<{ size: number; files: number; folders: number } | null>(
    null,
  );
  const [computing, setComputing] = useState(false);
  const [md5, setMd5] = useState<string | null>(null);

  useEffect(() => {
    if (!visible || !item) return;
    setFolderStats(null);
    setMd5(null);
    setComputing(false);
    const d = details(item.path, false);
    setInfo(d);
    if (!item.isDir && d.size && d.size > 0 && d.size < 32 * 1024 * 1024) {
      const timer = setTimeout(() => {
        try {
          setMd5(new File(fileUri(item.path)).md5 ?? null);
        } catch {
          setMd5(null);
        }
      }, 60);
      return () => clearTimeout(timer);
    }
    return undefined;
  }, [visible, item]);

  const computeFolderSize = async () => {
    if (!item) return;
    setComputing(true);
    try {
      const result = await dirSize(item.path);
      setFolderStats({ size: result.size, files: result.files, folders: result.folders });
    } finally {
      setComputing(false);
    }
  };

  if (!item) return null;

  const sizeText = item.isDir
    ? folderStats
      ? formatBytes(folderStats.size)
      : '—'
    : formatBytes(info?.size ?? item.size);

  const rows: { label: string; value: string; mono?: boolean }[] = [
    { label: t('infoName'), value: item.name },
    { label: t('infoPath'), value: item.path, mono: true },
    {
      label: t('infoType'),
      value: item.isDir
        ? t('folderLabel')
        : category
          ? `${t('fileLabel')} · ${categoryLabel(category, lang)}`
          : t('fileLabel'),
    },
    { label: t('infoSize'), value: sizeText },
  ];

  if (item.isDir && folderStats) {
    rows.push({
      label: t('infoContents'),
      value: t('infoContentsValue', { files: folderStats.files, folders: folderStats.folders }),
    });
  }

  if (!item.isDir) {
    rows.push({ label: t('infoExt'), value: item.ext ? `.${item.ext}` : '—' });
    if (info?.mime) rows.push({ label: t('infoMime'), value: info.mime, mono: true });
    if (md5) rows.push({ label: t('infoMd5'), value: md5, mono: true });
  }

  rows.push({ label: t('infoModified'), value: formatDateTime(info?.mtime ?? item.mtime, lang) });
  rows.push({ label: t('infoCreated'), value: formatDateTime(info?.ctime ?? item.ctime, lang) });

  return (
    <Sheet visible={visible} onClose={onClose} title={t('infoTitle')} subtitle={item.name}>
      <ScrollView contentContainerStyle={{ paddingHorizontal: SP.lg, paddingBottom: SP.sm }}>
        <View style={[styles.hero, { flexDirection: isRTL ? 'row-reverse' : 'row', backgroundColor: palette.surfaceAlt }]}>
          <View
            style={[
              styles.heroIcon,
              { backgroundColor: item.isDir ? 'rgba(255,200,97,0.16)' : `${category?.color ?? palette.accent}22` },
            ]}
          >
            <Ionicons
              name={
                (item.isDir ? 'folder' : (category?.icon ?? 'document')) as React.ComponentProps<
                  typeof Ionicons
                >['name']
              }
              size={26}
              color={item.isDir ? palette.folder : category?.color ?? palette.accent}
            />
          </View>
          <View style={{ flex: 1 }}>
            <Text style={[styles.heroName, { color: palette.text, textAlign: isRTL ? 'right' : 'left' }]}>
              {item.name}
            </Text>
            <Text style={[styles.heroMeta, { color: palette.textDim, textAlign: isRTL ? 'right' : 'left' }]}>
              {sizeText} · {item.isDir ? t('folderLabel') : (item.ext.toUpperCase() || t('fileLabel'))}
            </Text>
          </View>
        </View>

        {rows.map((row) => (
          <View key={row.label} style={[styles.row, { flexDirection: isRTL ? 'row-reverse' : 'row', borderBottomColor: palette.divider }]}>
            <Text style={[styles.rowLabel, { color: palette.textDim, textAlign: isRTL ? 'right' : 'left' }]}>
              {row.label}
            </Text>
            <View style={styles.rowValueWrap}>
              <Text
                selectable
                style={[
                  styles.rowValue,
                  {
                    color: palette.text,
                    textAlign: isRTL ? 'left' : 'right',
                    fontFamily: row.mono ? 'Menlo' : undefined,
                    fontSize: row.mono ? 12 : 14,
                  },
                ]}
              >
                {row.value}
              </Text>
            </View>
          </View>
        ))}

        {item.isDir ? (
          <TouchableOpacity
            style={[styles.sizeBtn, { backgroundColor: palette.surfaceAlt, borderColor: palette.border }]}
            onPress={computeFolderSize}
            disabled={computing}
          >
            {computing ? (
              <ActivityIndicator size="small" color={palette.accent} />
            ) : (
              <Ionicons name="calculator-outline" size={16} color={palette.accent} />
            )}
            <Text style={[styles.sizeBtnLabel, { color: palette.accent }]}>
              {computing ? t('infoComputing') : t('infoComputeSize')}
            </Text>
          </TouchableOpacity>
        ) : null}

        {!item.isDir && onShare ? (
          <TouchableOpacity
            style={[styles.sizeBtn, { backgroundColor: palette.accentSoft }]}
            onPress={onShare}
          >
            <Ionicons name="share-social-outline" size={16} color={palette.accent} />
            <Text style={[styles.sizeBtnLabel, { color: palette.accent }]}>{t('openWith')}</Text>
          </TouchableOpacity>
        ) : null}
      </ScrollView>
    </Sheet>
  );
}

const styles = StyleSheet.create({
  hero: { alignItems: 'center', gap: SP.md, padding: SP.md, borderRadius: RADIUS.md, marginBottom: SP.md },
  heroIcon: { width: 46, height: 46, borderRadius: RADIUS.md, alignItems: 'center', justifyContent: 'center' },
  heroName: { fontSize: 15, fontWeight: '700' },
  heroMeta: { fontSize: 12, marginTop: 2 },
  row: { paddingVertical: 11, borderBottomWidth: StyleSheet.hairlineWidth, gap: SP.md },
  rowLabel: { width: 110, fontSize: 13, fontWeight: '600' },
  rowValueWrap: { flex: 1 },
  rowValue: { fontWeight: '500' },
  sizeBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: SP.sm,
    marginTop: SP.lg,
    paddingVertical: 12,
    borderRadius: RADIUS.md,
    borderWidth: 1,
    borderColor: 'transparent',
  },
  sizeBtnLabel: { fontSize: 14, fontWeight: '700' },
});

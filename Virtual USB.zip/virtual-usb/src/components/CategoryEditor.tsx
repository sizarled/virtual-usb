import { Ionicons } from '@expo/vector-icons';
import React, { useEffect, useMemo, useState } from 'react';
import { ScrollView, StyleSheet, Text, TextInput, TouchableOpacity, View } from 'react-native';

import { COLOR_CHOICES, ICON_CHOICES, newCategoryId } from '../lib/categories';
import { cleanExtension } from '../lib/format';
import { useApp } from '../state/AppContext';
import { RADIUS, SP } from '../theme';
import { Sheet, SheetButton } from './Sheet';

export type EditableCategory = {
  id: string;
  labelAr: string;
  labelEn: string;
  icon: string;
  color: string;
  exts: string[];
  fallback?: boolean;
  builtin?: boolean;
};

export function CategoryEditor({
  visible,
  value,
  onClose,
  onSave,
  onDelete,
}: {
  visible: boolean;
  value: EditableCategory | null;
  onClose: () => void;
  onSave: (category: EditableCategory) => void;
  onDelete?: (category: EditableCategory) => void;
}) {
  const { palette, t, isRTL, categories } = useApp();
  const [draft, setDraft] = useState<EditableCategory | null>(value);
  const [extInput, setExtInput] = useState('');

  useEffect(() => {
    if (visible) {
      setDraft(value ? { ...value, exts: [...value.exts] } : null);
      setExtInput('');
    }
  }, [visible, value]);

  const foreignExts = useMemo(() => {
    const set = new Map<string, string>();
    for (const cat of categories) {
      if (value && cat.id === value.id) continue;
      for (const ext of cat.exts) set.set(ext.toLowerCase(), cat.id);
    }
    return set;
  }, [categories, value]);

  if (!draft) return null;

  const addExtension = () => {
    const ext = cleanExtension(extInput);
    if (!ext || !/^[a-z0-9.+-]+$/i.test(ext)) {
      return;
    }
    if (draft.exts.includes(ext)) {
      setExtInput('');
      return;
    }
    if (foreignExts.has(ext)) {
      // move it: still allow, but warn through the toast-less inline hint
      setDraft({ ...draft, exts: [...draft.exts, ext] });
      setExtInput('');
      return;
    }
    setDraft({ ...draft, exts: [...draft.exts, ext] });
    setExtInput('');
  };

  const removeExtension = (ext: string) =>
    setDraft({ ...draft, exts: draft.exts.filter((e) => e !== ext) });

  return (
    <Sheet visible={visible} onClose={onClose} title={draft.id ? t('editCategory') : t('addCategory')}>
      <ScrollView contentContainerStyle={{ paddingHorizontal: SP.lg, paddingBottom: SP.md }}>
        <Field label={t('categoryNameAr')} isRTL={isRTL}>
          <TextField
            value={draft.labelAr}
            onChangeText={(v) => setDraft({ ...draft, labelAr: v })}
            placeholder="الصوتيات"
          />
        </Field>

        <Field label={t('categoryNameEn')} isRTL={isRTL}>
          <TextField
            value={draft.labelEn}
            onChangeText={(v) => setDraft({ ...draft, labelEn: v })}
            placeholder="Audio"
          />
        </Field>

        <Text style={[styles.sectionLabel, { color: palette.textDim, textAlign: isRTL ? 'right' : 'left' }]}>
          {t('categoryIcon')}
        </Text>
        <View style={[styles.iconGrid, { flexDirection: isRTL ? 'row-reverse' : 'row' }]}>
          {ICON_CHOICES.map((icon) => {
            const active = draft.icon === icon;
            return (
              <TouchableOpacity
                key={icon}
                style={[
                  styles.iconCell,
                  {
                    backgroundColor: active ? `${draft.color}22` : palette.surfaceAlt,
                    borderColor: active ? draft.color : 'transparent',
                  },
                ]}
                onPress={() => setDraft({ ...draft, icon })}
              >
                <Ionicons
                  name={icon as React.ComponentProps<typeof Ionicons>['name']}
                  size={18}
                  color={active ? draft.color : palette.textDim}
                />
              </TouchableOpacity>
            );
          })}
        </View>

        <Text style={[styles.sectionLabel, { color: palette.textDim, textAlign: isRTL ? 'right' : 'left' }]}>
          {t('categoryColor')}
        </Text>
        <View style={[styles.colorRow, { flexDirection: isRTL ? 'row-reverse' : 'row' }]}>
          {COLOR_CHOICES.map((color) => (
            <TouchableOpacity
              key={color}
              onPress={() => setDraft({ ...draft, color })}
              style={[styles.colorDot, { backgroundColor: color, borderColor: draft.color === color ? palette.text : 'transparent' }]}
            />
          ))}
        </View>

        <Text style={[styles.sectionLabel, { color: palette.textDim, textAlign: isRTL ? 'right' : 'left' }]}>
          {t('extensions')} ({draft.exts.length})
        </Text>
        <View style={[styles.extWrap, { flexDirection: isRTL ? 'row-reverse' : 'row', backgroundColor: palette.surfaceAlt }]}>
          {draft.exts.length === 0 ? (
            <Text style={[styles.emptyExt, { color: palette.textFaint, textAlign: isRTL ? 'right' : 'left' }]}>
              {t('noExtensions')}
            </Text>
          ) : (
            <View style={[styles.extList, { flexDirection: isRTL ? 'row-reverse' : 'row' }]}>
              {draft.exts.map((ext) => (
                <TouchableOpacity
                  key={ext}
                  onPress={() => removeExtension(ext)}
                  style={[styles.extChip, { backgroundColor: `${draft.color}1F`, flexDirection: isRTL ? 'row-reverse' : 'row' }]}
                >
                  <Text style={[styles.extText, { color: draft.color }]}>{ext}</Text>
                  <Ionicons name="close" size={12} color={draft.color} />
                </TouchableOpacity>
              ))}
            </View>
          )}
        </View>

        <View style={[styles.addRow, { flexDirection: isRTL ? 'row-reverse' : 'row' }]}>
          <View style={[styles.addInput, { flex: 1, backgroundColor: palette.surfaceAlt, borderColor: palette.border }]}>
            <TextInput
              value={extInput}
              onChangeText={setExtInput}
              placeholder={t('addExtensionHint')}
              placeholderTextColor={palette.textFaint}
              autoCapitalize="none"
              autoCorrect={false}
              onSubmitEditing={addExtension}
              style={[styles.addInputText, { color: palette.text, textAlign: isRTL ? 'right' : 'left' }]}
            />
          </View>
          <TouchableOpacity style={[styles.addBtn, { backgroundColor: palette.accent }]} onPress={addExtension}>
            <Ionicons name="add" size={20} color={palette.accentContrast} />
          </TouchableOpacity>
        </View>

        <SheetButton
          label={t('save')}
          icon="checkmark"
          onPress={() => {
            const cleaned: EditableCategory = {
              ...draft,
              labelAr: draft.labelAr.trim() || draft.labelEn.trim() || draft.id,
              labelEn: draft.labelEn.trim() || draft.labelAr.trim() || draft.id,
              id: draft.id || newCategoryId(),
            };
            onSave(cleaned);
          }}
        />
        {onDelete && !draft.fallback ? (
          <SheetButton label={t('delete')} icon="trash-outline" variant="danger" onPress={() => onDelete(draft)} />
        ) : null}
      </ScrollView>
    </Sheet>
  );
}

function Field({
  label,
  isRTL,
  children,
}: {
  label: string;
  isRTL: boolean;
  children: React.ReactNode;
}) {
  const { palette } = useApp();
  return (
    <View style={{ marginBottom: SP.md }}>
      <Text style={[styles.sectionLabel, { color: palette.textDim, textAlign: isRTL ? 'right' : 'left' }]}>
        {label}
      </Text>
      {children}
    </View>
  );
}

function TextField({
  value,
  onChangeText,
  placeholder,
}: {
  value: string;
  onChangeText: (v: string) => void;
  placeholder?: string;
}) {
  const { palette, isRTL } = useApp();
  return (
    <View style={[styles.textField, { backgroundColor: palette.surfaceAlt, borderColor: palette.border }]}>
      <TextInput
        value={value}
        onChangeText={onChangeText}
        placeholder={placeholder}
        placeholderTextColor={palette.textFaint}
        style={[styles.textFieldInput, { color: palette.text, textAlign: isRTL ? 'right' : 'left' }]}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  sectionLabel: { fontSize: 12, fontWeight: '700', marginBottom: SP.sm, marginTop: SP.md },
  textField: { borderWidth: 1, borderRadius: RADIUS.md, paddingHorizontal: SP.md, paddingVertical: 9 },
  textFieldInput: { fontSize: 15 },
  iconGrid: { flexWrap: 'wrap', gap: SP.sm },
  iconCell: {
    width: 42,
    height: 42,
    borderRadius: RADIUS.md,
    borderWidth: 1.5,
    alignItems: 'center',
    justifyContent: 'center',
  },
  colorRow: { flexWrap: 'wrap', gap: SP.md },
  colorDot: { width: 28, height: 28, borderRadius: 14, borderWidth: 2 },
  extWrap: { borderRadius: RADIUS.md, padding: SP.sm, minHeight: 44, alignItems: 'center' },
  extList: { flexWrap: 'wrap', gap: 6, flex: 1 },
  emptyExt: { fontSize: 12, flex: 1 },
  extChip: {
    alignItems: 'center',
    paddingHorizontal: 9,
    paddingVertical: 5,
    borderRadius: RADIUS.pill,
    gap: 4,
  },
  extText: { fontSize: 12, fontWeight: '700' },
  addRow: { alignItems: 'center', gap: SP.sm, marginTop: SP.md },
  addInput: { borderWidth: 1, borderRadius: RADIUS.md, paddingHorizontal: SP.md, paddingVertical: 8 },
  addInputText: { fontSize: 14 },
  addBtn: { width: 44, height: 44, borderRadius: RADIUS.md, alignItems: 'center', justifyContent: 'center' },
});

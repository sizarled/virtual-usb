import { Ionicons } from '@expo/vector-icons';
import Constants from 'expo-constants';
import React, { useState } from 'react';
import { Platform, ScrollView, StyleSheet, Switch, Text, TextInput, TouchableOpacity, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import { CategoryEditor, EditableCategory } from '../components/CategoryEditor';
import { ConfirmDialog } from '../components/Dialogs';
import { COLOR_CHOICES } from '../lib/categories';
import { formatBytes } from '../lib/format';
import { createDirectory, diskSpace, pathInfo } from '../lib/fs';
import { normalizePath } from '../lib/paths';
import { useApp } from '../state/AppContext';
import { Lang } from '../i18n/strings';
import { RADIUS, SP, ThemeMode } from '../theme';

export function SettingsScreen({ onBack }: { onBack: () => void }) {
  const { settings, updateSettings, categories, setCategories, resetCategories, palette, t, lang, isRTL, showToast, sandboxRoot } =
    useApp();
  const insets = useSafeAreaInsets();

  const [rootDraft, setRootDraft] = useState(settings.root);
  const [testResult, setTestResult] = useState<'ok' | 'fail' | null>(null);
  const [editor, setEditor] = useState<EditableCategory | null>(null);
  const [editorOpen, setEditorOpen] = useState(false);
  const [confirmReset, setConfirmReset] = useState(false);
  const [pendingDelete, setPendingDelete] = useState<EditableCategory | null>(null);
  const [space] = useState(() => diskSpace());

  const rowDir = isRTL ? 'row-reverse' : 'row';
  const textAlign = isRTL ? 'right' : 'left';

  const testPath = () => {
    const info = pathInfo(normalizePath(rootDraft.trim() || '/'));
    setTestResult(info.exists && info.isDirectory ? 'ok' : 'fail');
  };

  const saveRoot = () => {
    const next = normalizePath(rootDraft.trim() || '/');
    updateSettings({ root: next });
    setRootDraft(next);
    setTestResult(null);
    showToast(t('done'), 'success');
  };

  const saveCategory = (next: EditableCategory) => {
    setEditorOpen(false);
    setEditor(null);
    setCategories((prev) => {
      const exists = prev.some((c) => c.id === next.id);
      return exists ? prev.map((c) => (c.id === next.id ? { ...c, ...next } : c)) : [...prev, { ...next }];
    });
    showToast(t('done'), 'success');
  };

  const deleteCategory = (cat: EditableCategory) => {
    setPendingDelete(null);
    setCategories((prev) => prev.filter((c) => c.id !== cat.id));
    showToast(t('deletedItems', { n: 1 }), 'success');
  };

  return (
    <View style={[styles.root, { backgroundColor: palette.bg }]}>
      <View style={[styles.header, { paddingTop: insets.top + SP.sm, flexDirection: rowDir }]}>
        <TouchableOpacity onPress={onBack} style={styles.backBtn}>
          <Ionicons name={isRTL ? 'chevron-forward' : 'chevron-back'} size={24} color={palette.text} />
        </TouchableOpacity>
        <Text style={[styles.headerTitle, { color: palette.text, textAlign }]}>{t('settingsTitle')}</Text>
      </View>

      <ScrollView contentContainerStyle={{ paddingBottom: insets.bottom + 40 }}>
        {/* ---------------------------- Storage ---------------------------- */}
        <SectionTitle label={t('sectionStorage')} />
        <View style={[styles.card, { backgroundColor: palette.surface, borderColor: palette.border }]}>
          <Text style={[styles.fieldLabel, { color: palette.textDim, textAlign }]}>{t('rootPath')}</Text>
          <View style={[styles.pathRow, { flexDirection: rowDir }]}>
            <View style={[styles.pathInput, { flex: 1, backgroundColor: palette.surfaceAlt, borderColor: palette.border }]}>
              <TextInput
                value={rootDraft}
                onChangeText={(v) => {
                  setRootDraft(v);
                  setTestResult(null);
                }}
                autoCapitalize="none"
                autoCorrect={false}
                placeholder="/general_storage"
                placeholderTextColor={palette.textFaint}
                style={[styles.pathInputText, { color: palette.text, textAlign }]}
              />
            </View>
            <TouchableOpacity style={[styles.smallBtn, { backgroundColor: palette.surfaceAlt }]} onPress={testPath}>
              <Text style={[styles.smallBtnLabel, { color: palette.text }]}>{t('testPath')}</Text>
            </TouchableOpacity>
          </View>
          {testResult ? (
            <Text style={[styles.testResult, { color: testResult === 'ok' ? palette.success : palette.danger, textAlign }]}>
              {testResult === 'ok' ? t('pathOk') : t('pathFail')}
            </Text>
          ) : null}
          <View style={[styles.pathActions, { flexDirection: rowDir }]}>
            <TouchableOpacity style={[styles.smallBtn, { backgroundColor: palette.accent }]} onPress={saveRoot}>
              <Text style={[styles.smallBtnLabel, { color: palette.accentContrast }]}>{t('save')}</Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={[styles.smallBtn, { backgroundColor: palette.surfaceAlt }]}
              onPress={() => {
                setRootDraft(sandboxRoot);
                try {
                  createDirectory(sandboxRoot);
                } catch {
                  /* ignore — the browser screen will offer to create it */
                }
                updateSettings({ root: sandboxRoot });
                setTestResult(null);
                showToast(t('done'), 'success');
              }}
            >
              <Text style={[styles.smallBtnLabel, { color: palette.text }]}>{t('safeMode')}</Text>
            </TouchableOpacity>
          </View>
          <Text style={[styles.hint, { color: palette.textFaint, textAlign }]}>{t('rootPathHint')}</Text>
          <Text style={[styles.hint, { color: palette.textFaint, textAlign }]}>{t('safeModeHint')}</Text>
        </View>

        {/* ---------------------------- Language --------------------------- */}
        <SectionTitle label={t('sectionLanguage')} />
        <View style={[styles.card, { backgroundColor: palette.surface, borderColor: palette.border }]}>
          <ChipGroup<Lang | 'system'>
            value={settings.lang}
            onChange={(value) => updateSettings({ lang: value })}
            options={[
              { value: 'system', label: t('langSystem') },
              { value: 'ar', label: t('langArabic') },
              { value: 'en', label: t('langEnglish') },
            ]}
          />
        </View>

        {/* --------------------------- Appearance -------------------------- */}
        <SectionTitle label={t('sectionAppearance')} />
        <View style={[styles.card, { backgroundColor: palette.surface, borderColor: palette.border }]}>
          <ChipGroup<ThemeMode>
            value={settings.theme}
            onChange={(value) => updateSettings({ theme: value })}
            options={[
              { value: 'system', label: t('themeSystem') },
              { value: 'light', label: t('themeLight') },
              { value: 'dark', label: t('themeDark') },
            ]}
          />
        </View>

        {/* --------------------------- View options ------------------------ */}
        <SectionTitle label={t('sectionView')} />
        <View style={[styles.card, { backgroundColor: palette.surface, borderColor: palette.border }]}>
          <Toggle
            label={t('recursiveSearch')}
            hint={t('recursiveSearchHint')}
            value={settings.recursive}
            onChange={(v) => updateSettings({ recursive: v })}
          />
          <Toggle
            label={t('showHidden')}
            hint={t('showHiddenHint')}
            value={settings.showHidden}
            onChange={(v) => updateSettings({ showHidden: v })}
          />
          <Toggle
            label={t('foldersFirst')}
            value={settings.foldersFirst}
            onChange={(v) => updateSettings({ foldersFirst: v })}
          />
        </View>

        {/* ---------------------------- Categories ------------------------- */}
        <SectionTitle label={t('sectionCategories')} />
        <View style={[styles.card, { backgroundColor: palette.surface, borderColor: palette.border }]}>
          <Text style={[styles.hint, { color: palette.textFaint, textAlign, marginBottom: SP.sm }]}>
            {t('categoriesHint')}
          </Text>
          {categories.map((cat) => {
            const label = lang === 'ar' ? cat.labelAr || cat.labelEn : cat.labelEn || cat.labelAr;
            return (
              <View key={cat.id} style={[styles.catRow, { flexDirection: rowDir, borderBottomColor: palette.divider }]}>
                <View style={[styles.catIcon, { backgroundColor: `${cat.color}22` }]}>
                  <Ionicons
                    name={cat.icon as React.ComponentProps<typeof Ionicons>['name']}
                    size={18}
                    color={cat.color}
                  />
                </View>
                <View style={{ flex: 1 }}>
                  <Text style={[styles.catName, { color: palette.text, textAlign }]}>{label}</Text>
                  <Text style={[styles.catMeta, { color: palette.textFaint, textAlign }]}>
                    {cat.fallback ? t('fallbackTag') : t('extensions') + ': ' + cat.exts.length}
                  </Text>
                </View>
                {cat.builtin ? (
                  <View style={[styles.tag, { backgroundColor: palette.surfaceAlt }]}>
                    <Text style={[styles.tagLabel, { color: palette.textFaint }]}>{t('builtinTag')}</Text>
                  </View>
                ) : null}
                <TouchableOpacity
                  style={styles.catAction}
                  onPress={() => {
                    setEditor({ ...cat, exts: [...cat.exts] });
                    setEditorOpen(true);
                  }}
                >
                  <Ionicons name="create-outline" size={18} color={palette.accent} />
                </TouchableOpacity>
                {!cat.fallback ? (
                  <TouchableOpacity style={styles.catAction} onPress={() => setPendingDelete(cat)}>
                    <Ionicons name="trash-outline" size={18} color={palette.danger} />
                  </TouchableOpacity>
                ) : null}
              </View>
            );
          })}
          <View style={[styles.pathActions, { flexDirection: rowDir, marginTop: SP.md }]}>
            <TouchableOpacity
              style={[styles.smallBtn, { backgroundColor: palette.accent }]}
              onPress={() => {
                setEditor({
                  id: '',
                  labelAr: '',
                  labelEn: '',
                  icon: 'document',
                  color: COLOR_CHOICES[1],
                  exts: [],
                });
                setEditorOpen(true);
              }}
            >
              <Text style={[styles.smallBtnLabel, { color: palette.accentContrast }]}>{t('addCategory')}</Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={[styles.smallBtn, { backgroundColor: palette.surfaceAlt }]}
              onPress={() => setConfirmReset(true)}
            >
              <Text style={[styles.smallBtnLabel, { color: palette.text }]}>{t('resetCategories')}</Text>
            </TouchableOpacity>
          </View>
        </View>

        {/* ------------------------------- About ---------------------------- */}
        <SectionTitle label={t('sectionAbout')} />
        <View style={[styles.card, { backgroundColor: palette.surface, borderColor: palette.border }]}>
          <InfoRow label={t('aboutApp')} value="" />
          <InfoRow label={t('version')} value={String(Constants.expoConfig?.version ?? '1.0.0')} />
          <InfoRow label={t('platform')} value={`${Platform.OS} ${Platform.Version}`} />
          <InfoRow
            label={t('storage')}
            value={`${formatBytes(space.free)} ${t('free')} ${t('of')} ${formatBytes(space.total)}`}
          />
          <Text style={[styles.notes, { color: palette.textDim, textAlign }]}>{t('notesBody')}</Text>
        </View>
      </ScrollView>

      <CategoryEditor
        visible={editorOpen}
        value={editor}
        onClose={() => {
          setEditorOpen(false);
          setEditor(null);
        }}
        onSave={saveCategory}
      />

      <ConfirmDialog
        visible={confirmReset}
        title={t('confirmResetCategories')}
        message={t('confirmResetCategoriesHint')}
        confirmLabel={t('resetCategories')}
        danger
        onConfirm={() => {
          setConfirmReset(false);
          resetCategories();
          showToast(t('done'), 'success');
        }}
        onCancel={() => setConfirmReset(false)}
      />

      <ConfirmDialog
        visible={!!pendingDelete}
        title={
          pendingDelete
            ? t('confirmDeleteCategory', {
                name: lang === 'ar' ? pendingDelete.labelAr || pendingDelete.labelEn : pendingDelete.labelEn,
              })
            : ''
        }
        message={t('confirmDeleteCategoryHint')}
        confirmLabel={t('delete')}
        danger
        onConfirm={() => pendingDelete && deleteCategory(pendingDelete)}
        onCancel={() => setPendingDelete(null)}
      />
    </View>
  );
}

/* ----------------------------- small components ---------------------------- */

function SectionTitle({ label }: { label: string }) {
  const { palette, isRTL } = useApp();
  return (
    <Text
      style={[styles.sectionTitle, { color: palette.textDim, textAlign: isRTL ? 'right' : 'left' }]}
    >
      {label}
    </Text>
  );
}

function InfoRow({ label, value }: { label: string; value: string }) {
  const { palette, isRTL } = useApp();
  return (
    <View style={[styles.infoRow, { flexDirection: isRTL ? 'row-reverse' : 'row' }]}>
      <Text style={[styles.infoLabel, { color: palette.textDim, textAlign: isRTL ? 'right' : 'left' }]}>
        {label}
      </Text>
      {value ? (
        <Text style={[styles.infoValue, { color: palette.text, textAlign: isRTL ? 'left' : 'right' }]}>
          {value}
        </Text>
      ) : null}
    </View>
  );
}

function Toggle({
  label,
  hint,
  value,
  onChange,
}: {
  label: string;
  hint?: string;
  value: boolean;
  onChange: (value: boolean) => void;
}) {
  const { palette, isRTL } = useApp();
  return (
    <View style={[styles.toggleRow, { flexDirection: isRTL ? 'row-reverse' : 'row' }]}>
      <View style={{ flex: 1 }}>
        <Text style={[styles.toggleLabel, { color: palette.text, textAlign: isRTL ? 'right' : 'left' }]}>
          {label}
        </Text>
        {hint ? (
          <Text style={[styles.hint, { color: palette.textFaint, textAlign: isRTL ? 'right' : 'left' }]}>
            {hint}
          </Text>
        ) : null}
      </View>
      <Switch
        value={value}
        onValueChange={onChange}
        trackColor={{ false: palette.border, true: palette.accent }}
        thumbColor={palette.bgAlt}
      />
    </View>
  );
}

function ChipGroup<T extends string>({
  value,
  options,
  onChange,
}: {
  value: T;
  options: { value: T; label: string }[];
  onChange: (value: T) => void;
}) {
  const { palette, isRTL } = useApp();
  return (
    <View style={[styles.chipRow, { flexDirection: isRTL ? 'row-reverse' : 'row' }]}>
      {options.map((option) => {
        const active = option.value === value;
        return (
          <TouchableOpacity
            key={option.value}
            onPress={() => onChange(option.value)}
            style={[
              styles.chip,
              { backgroundColor: active ? palette.accent : palette.surfaceAlt, borderColor: active ? palette.accent : palette.border },
            ]}
          >
            <Text style={[styles.chipLabel, { color: active ? palette.accentContrast : palette.text }]}>
              {option.label}
            </Text>
          </TouchableOpacity>
        );
      })}
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1 },
  header: { alignItems: 'center', paddingHorizontal: SP.lg, paddingBottom: SP.sm, gap: SP.sm },
  backBtn: { padding: 4 },
  headerTitle: { flex: 1, fontSize: 18, fontWeight: '800' },
  sectionTitle: {
    fontSize: 12,
    fontWeight: '800',
    letterSpacing: 0.4,
    paddingHorizontal: SP.lg,
    paddingTop: SP.xl,
    paddingBottom: SP.sm,
  },
  card: {
    marginHorizontal: SP.lg,
    borderRadius: RADIUS.md,
    borderWidth: 1,
    padding: SP.md,
  },
  fieldLabel: { fontSize: 12, fontWeight: '700', marginBottom: SP.sm },
  pathRow: { alignItems: 'center', gap: SP.sm },
  pathInput: { borderWidth: 1, borderRadius: RADIUS.sm, paddingHorizontal: SP.md, paddingVertical: 8 },
  pathInputText: { fontSize: 14, fontFamily: 'Menlo' },
  pathActions: { alignItems: 'center', gap: SP.sm, marginTop: SP.md },
  smallBtn: { paddingHorizontal: SP.md, paddingVertical: 9, borderRadius: RADIUS.sm },
  smallBtnLabel: { fontSize: 13, fontWeight: '700' },
  testResult: { fontSize: 12, fontWeight: '700', marginTop: SP.sm },
  hint: { fontSize: 11, lineHeight: 16, marginTop: 6 },
  chipRow: { gap: SP.sm, flexWrap: 'wrap' },
  chip: { paddingHorizontal: SP.md, paddingVertical: 9, borderRadius: RADIUS.pill, borderWidth: 1 },
  chipLabel: { fontSize: 13, fontWeight: '700' },
  toggleRow: { alignItems: 'center', paddingVertical: 9, gap: SP.md },
  toggleLabel: { fontSize: 14, fontWeight: '600' },
  catRow: {
    alignItems: 'center',
    paddingVertical: 10,
    gap: SP.sm,
    borderBottomWidth: StyleSheet.hairlineWidth,
  },
  catIcon: { width: 34, height: 34, borderRadius: 10, alignItems: 'center', justifyContent: 'center' },
  catName: { fontSize: 14, fontWeight: '700' },
  catMeta: { fontSize: 11, marginTop: 2 },
  tag: { paddingHorizontal: 7, paddingVertical: 3, borderRadius: RADIUS.pill },
  tagLabel: { fontSize: 10, fontWeight: '700' },
  catAction: { padding: 6 },
  infoRow: { paddingVertical: 7, gap: SP.md, alignItems: 'center' },
  infoLabel: { flex: 1, fontSize: 13, color: '#8A94A6' },
  infoValue: { fontSize: 13, fontWeight: '600' },
  notes: { fontSize: 11, lineHeight: 18, marginTop: SP.sm },
});

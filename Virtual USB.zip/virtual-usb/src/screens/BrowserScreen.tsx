import { Ionicons } from '@expo/vector-icons';
import * as DocumentPicker from 'expo-document-picker';
import * as Haptics from 'expo-haptics';
import * as Sharing from 'expo-sharing';
import React, { useCallback, useEffect, useMemo, useState } from 'react';
import {
  ActivityIndicator,
  FlatList,
  RefreshControl,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import { CategoryBar, PathBar } from '../components/Bars';
import { ActionMenuDialog, ConfirmDialog, PromptDialog } from '../components/Dialogs';
import { EmptyView } from '../components/Feedback';
import { InfoSheet } from '../components/InfoSheet';
import { ItemRow } from '../components/ItemRow';
import { Sheet, SheetAction } from '../components/Sheet';
import { StrKey } from '../i18n/strings';
import {
  categoryForItem,
  Category,
  categoryMap,
  FALLBACK_CATEGORY_ID,
} from '../lib/categories';
import { formatBytes } from '../lib/format';
import {
  copyPath,
  copyUriToPath,
  createDirectory,
  describeFsError,
  diskSpace,
  exists,
  FsItem,
  listDirectory,
  movePath,
  ProgressFn,
  removeFile,
  removePath,
  renamePath,
  uniquePath,
  walkItems,
} from '../lib/fs';
import { dirname, fileUri, isInside, isValidName, joinPath, normalizePath } from '../lib/paths';
import { useApp } from '../state/AppContext';
import { RADIUS, SP } from '../theme';

type ClipItem = { path: string; name: string; isDir: boolean };
type ClipboardState = { mode: 'copy' | 'cut'; items: ClipItem[] } | null;
type Pending =
  | { kind: 'delete'; items: FsItem[] }
  | { kind: 'replace'; item: FsItem }
  | { kind: 'createRoot' }
  | null;
type PromptState = { kind: 'folder' } | { kind: 'rename'; item: FsItem } | null;

export function BrowserScreen({ onOpenSettings }: { onOpenSettings: () => void }) {
  const { settings, updateSettings, categories, palette, t, isRTL, showToast, setBusy, sandboxRoot } =
    useApp();
  const insets = useSafeAreaInsets();

  const [cwd, setCwd] = useState(settings.root);
  const [items, setItems] = useState<FsItem[]>([]);
  const [loading, setLoading] = useState(false);
  const [accessError, setAccessError] = useState(false);
  const [query, setQuery] = useState('');
  const [activeCategory, setActiveCategory] = useState('all');
  const [selected, setSelected] = useState<string[]>([]);
  const [selectionMode, setSelectionMode] = useState(false);
  const [clipboard, setClipboard] = useState<ClipboardState>(null);
  const [menuItem, setMenuItem] = useState<FsItem | null>(null);
  const [infoItem, setInfoItem] = useState<FsItem | null>(null);
  const [pending, setPending] = useState<Pending>(null);
  const [prompt, setPrompt] = useState<PromptState>(null);
  const [sortOpen, setSortOpen] = useState(false);
  const [fabOpen, setFabOpen] = useState(false);
  const [deepItems, setDeepItems] = useState<{ rel: string; item: FsItem }[]>([]);
  const [space, setSpace] = useState({ total: 0, free: 0 });
  const [replaceUri, setReplaceUri] = useState<string | null>(null);

  const catMap = useMemo(() => categoryMap(categories), [categories]);
  const categoryOf = useCallback(
    (item: FsItem): Category =>
      categoryForItem(categories, item) ??
      catMap[FALLBACK_CATEGORY_ID] ??
      categories[categories.length - 1],
    [categories, catMap],
  );

  /* ------------------------------- loading ------------------------------- */

  const load = useCallback(async (target: string) => {
    setCwd(target);
    setLoading(true);
    await new Promise<void>((resolve) => setTimeout(resolve, 0));
    try {
      const list = listDirectory(target);
      setItems(list);
      setAccessError(false);
    } catch {
      setItems([]);
      setAccessError(true);
    } finally {
      setLoading(false);
    }
  }, []);

  const refresh = useCallback(() => {
    setSpace(diskSpace());
    load(cwd);
  }, [cwd, load]);

  useEffect(() => {
    setCwd(settings.root);
    setSelected([]);
    setSelectionMode(false);
    load(settings.root);
    setSpace(diskSpace());
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [settings.root]);

  // Recursive scan (only needed for counts / deep category browsing)
  useEffect(() => {
    if (!settings.recursive) {
      setDeepItems([]);
      return;
    }
    let cancelled = false;
    const timer = setTimeout(() => {
      try {
        const found = walkItems(cwd);
        if (!cancelled) setDeepItems(found);
      } catch {
        if (!cancelled) setDeepItems([]);
      }
    }, 150);
    return () => {
      cancelled = true;
      clearTimeout(timer);
    };
  }, [cwd, items, settings.recursive]);

  /* ------------------------------ navigation ----------------------------- */

  const navigate = (target: string) => {
    if (!isInside(settings.root, target)) return;
    setSelected([]);
    setSelectionMode(false);
    setQuery('');
    load(target);
  };

  const goUp = () => {
    const parent = dirname(cwd);
    if (isInside(settings.root, parent) && parent !== cwd) navigate(parent);
  };

  const crumbs = useMemo(() => {
    const rel = cwd === settings.root ? '' : normalizePath(cwd).slice(normalizePath(settings.root).length);
    const parts = rel.split('/').filter(Boolean);
    const out = [{ path: settings.root, name: t('rootCrumb') }];
    let acc = settings.root;
    for (const part of parts) {
      acc = joinPath(acc, part);
      out.push({ path: acc, name: part });
    }
    return out;
  }, [cwd, settings.root, t]);

  /* ------------------------------- derived ------------------------------- */

  const counts = useMemo(() => {
    const c: Record<string, number> = {};
    const source = settings.recursive ? deepItems.map((d) => d.item) : items.filter((i) => !i.isDir);
    for (const item of source) {
      const id = categoryForItem(categories, item).id;
      c[id] = (c[id] ?? 0) + 1;
    }
    return c;
  }, [items, deepItems, categories, settings.recursive]);

  const rows = useMemo(() => {
    const q = query.trim().toLowerCase();
    const source: { item: FsItem; rel?: string }[] =
      activeCategory === 'all'
        ? items.map((item) => ({ item }))
        : settings.recursive
          ? deepItems.map((d) => ({ item: d.item, rel: d.rel }))
          : items.filter((i) => !i.isDir).map((item) => ({ item }));

    return source
      .filter(({ item }) => settings.showHidden || !item.name.startsWith('.'))
      .filter(({ item }) => !q || item.name.toLowerCase().includes(q))
      .filter(({ item }) => {
        if (activeCategory === 'all') return true;
        if (item.isDir) return false;
        return categoryForItem(categories, item).id === activeCategory;
      })
      .map(({ item, rel }) => ({
        item,
        subtitle: rel && rel.includes('/') ? rel.slice(0, rel.lastIndexOf('/')) : undefined,
      }));
  }, [items, deepItems, activeCategory, settings.recursive, settings.showHidden, query, categories]);

  const sortedRows = useMemo(() => {
    const dir = settings.sortDir === 'asc' ? 1 : -1;
    return [...rows].sort((a, b) => {
      if (settings.foldersFirst && a.item.isDir !== b.item.isDir) return a.item.isDir ? -1 : 1;
      switch (settings.sortKey) {
        case 'size':
          return (a.item.size - b.item.size) * dir;
        case 'date':
          return ((a.item.mtime ?? 0) - (b.item.mtime ?? 0)) * dir;
        case 'type':
          return (a.item.ext || '').localeCompare(b.item.ext || '') * dir;
        default:
          return a.item.name.localeCompare(b.item.name, undefined, { numeric: true }) * dir;
      }
    });
  }, [rows, settings.sortKey, settings.sortDir, settings.foldersFirst]);

  const resolveItem = useCallback(
    (path: string): FsItem | undefined =>
      items.find((i) => i.path === path) ?? deepItems.find((d) => d.item.path === path)?.item,
    [items, deepItems],
  );

  const selectedItems = useMemo(
    () => selected.map((p) => resolveItem(p)).filter((i): i is FsItem => !!i),
    [selected, resolveItem],
  );

  /* ------------------------------- selection ------------------------------ */

  const toggleSelect = (path: string) =>
    setSelected((prev) => (prev.includes(path) ? prev.filter((p) => p !== path) : [...prev, path]));

  const enterSelection = (item: FsItem) => {
    setSelectionMode(true);
    setSelected([item.path]);
    Haptics.selectionAsync().catch(() => {});
  };

  const exitSelection = () => {
    setSelectionMode(false);
    setSelected([]);
  };

  const selectAllVisible = () => setSelected(sortedRows.map((r) => r.item.path));

  /* ------------------------------ operations ------------------------------ */

  const withBusy = async (label: string, task: (progress: ProgressFn) => Promise<void>) => {
    setBusy({ label });
    try {
      await task((p) => setBusy({ label, done: p.done, total: p.total }));
      return true;
    } catch (error) {
      showToast(describeFsError(error, (k) => t(k as StrKey)), 'error');
      return false;
    } finally {
      setBusy(null);
    }
  };

  const doCopy = (list: FsItem[]) => {
    if (!list.length) return;
    setClipboard({ mode: 'copy', items: list.map((i) => ({ path: i.path, name: i.name, isDir: i.isDir })) });
    exitSelection();
    setMenuItem(null);
    showToast(t('clipboardCopy', { n: list.length }), 'success');
  };

  const doCut = (list: FsItem[]) => {
    if (!list.length) return;
    setClipboard({ mode: 'cut', items: list.map((i) => ({ path: i.path, name: i.name, isDir: i.isDir })) });
    exitSelection();
    setMenuItem(null);
    showToast(t('clipboardCut', { n: list.length }), 'success');
  };

  const doPaste = async () => {
    if (!clipboard || !clipboard.items.length) {
      showToast(t('nothingToPaste'));
      return;
    }
    const moving = clipboard.mode === 'cut';
    const queue = clipboard.items.filter((it) => !(moving && dirname(it.path) === cwd));
    if (!queue.length) {
      showToast(t('nothingToPaste'));
      setClipboard(null);
      return;
    }
    let done = 0;
    const ok = await withBusy(moving ? t('workingMove') : t('workingCopy'), async (progress) => {
      for (const it of queue) {
        progress({ done, total: queue.length, current: it.name });
        const dest = uniquePath(cwd, it.name);
        if (moving) await movePath(it.path, dest);
        else await copyPath(it.path, dest);
        done += 1;
        progress({ done, total: queue.length, current: it.name });
      }
    });
    if (ok) showToast(moving ? t('pasteDoneMove', { n: queue.length }) : t('pasteDoneCopy', { n: queue.length }), 'success');
    if (moving) setClipboard(null);
    refresh();
  };

  const doDelete = async (list: FsItem[]) => {
    setPending(null);
    setMenuItem(null);
    const ok = await withBusy(t('workingDelete'), async (progress) => {
      let done = 0;
      for (const item of list) {
        progress({ done, total: list.length, current: item.name });
        await removePath(item.path);
        done += 1;
        progress({ done, total: list.length, current: item.name });
      }
    });
    if (ok) showToast(t('deletedItems', { n: list.length }), 'success');
    exitSelection();
    refresh();
  };

  const doRename = (item: FsItem, raw: string) => {
    const name = raw.trim();
    setPrompt(null);
    if (!isValidName(name)) {
      showToast(t('errInvalidName'), 'error');
      return;
    }
    const target = joinPath(dirname(item.path), name);
    if (normalizePath(target) !== normalizePath(item.path) && exists(target)) {
      showToast(t('errNameTaken'), 'error');
      return;
    }
    try {
      renamePath(item.path, name);
      showToast(t('renamedItem'), 'success');
      refresh();
    } catch (error) {
      showToast(describeFsError(error, (k) => t(k as StrKey)), 'error');
    }
  };

  const doCreateFolder = (raw: string) => {
    const name = raw.trim();
    setPrompt(null);
    if (!isValidName(name)) {
      showToast(t('errInvalidName'), 'error');
      return;
    }
    const target = joinPath(cwd, name);
    if (exists(target)) {
      showToast(t('errNameTaken'), 'error');
      return;
    }
    try {
      createDirectory(target);
      showToast(t('createdFolder'), 'success');
      refresh();
    } catch (error) {
      showToast(describeFsError(error, (k) => t(k as StrKey)), 'error');
    }
  };

  const doImport = async () => {
    try {
      const result = await DocumentPicker.getDocumentAsync({
        multiple: true,
        copyToCacheDirectory: true,
      });
      if (result.canceled || !result.assets?.length) return;
      const assets = result.assets;
      const ok = await withBusy(t('workingImport'), async (progress) => {
        for (let i = 0; i < assets.length; i += 1) {
          const asset = assets[i];
          progress({ done: i, total: assets.length, current: asset.name });
          copyUriToPath(asset.uri, uniquePath(cwd, asset.name || `file_${Date.now()}`));
          await new Promise<void>((r) => setTimeout(r, 0));
        }
      });
      if (ok) showToast(t('importedFiles', { n: assets.length }), 'success');
      refresh();
    } catch {
      showToast(t('errImportFailed'), 'error');
    }
  };

  const startReplace = async (item: FsItem) => {
    setMenuItem(null);
    try {
      const result = await DocumentPicker.getDocumentAsync({
        multiple: false,
        copyToCacheDirectory: true,
      });
      if (result.canceled || !result.assets?.length) return;
      setReplaceUri(result.assets[0].uri);
      setPending({ kind: 'replace', item });
    } catch {
      showToast(t('errImportFailed'), 'error');
    }
  };

  const doReplace = async () => {
    const item = pending?.kind === 'replace' ? pending.item : null;
    const uri = replaceUri;
    setPending(null);
    setReplaceUri(null);
    if (!item || !uri) return;
    const ok = await withBusy(t('workingImport'), async () => {
      const tmp = joinPath(dirname(item.path), `.${item.name}.${Date.now()}.tmp`);
      copyUriToPath(uri, tmp);
      removeFile(item.path);
      renamePath(tmp, item.name);
    });
    if (ok) showToast(t('updatedFile'), 'success');
    refresh();
  };

  const switchToSandbox = () => {
    try {
      createDirectory(sandboxRoot);
    } catch {
      /* ignore — the error screen will offer to create it */
    }
    updateSettings({ root: sandboxRoot });
  };

  const doCreateRoot = async () => {
    setPending(null);
    const ok = await withBusy(t('workingScan'), async () => {
      createDirectory(settings.root);
    });
    if (ok) {
      showToast(t('rootCreated'), 'success');
      refresh();
    }
  };

  const doShare = async (item: FsItem) => {
    setMenuItem(null);
    try {
      const available = await Sharing.isAvailableAsync();
      if (!available) {
        showToast(t('errShareUnavailable'), 'error');
        return;
      }
      await Sharing.shareAsync(fileUri(item.path), { mimeType: item.mime || undefined });
    } catch {
      showToast(t('errShareUnavailable'), 'error');
    }
  };

  /* --------------------------------- menus -------------------------------- */

  const itemActions = (item: FsItem): SheetAction[] => {
    const actions: SheetAction[] = [];
    if (!item.isDir) {
      actions.push({ key: 'open', label: t('openWith'), icon: 'open-outline', onPress: () => doShare(item) });
    }
    actions.push(
      { key: 'rename', label: t('rename'), icon: 'create-outline', onPress: () => { setMenuItem(null); setPrompt({ kind: 'rename', item }); } },
      { key: 'copy', label: t('copy'), icon: 'copy-outline', onPress: () => doCopy([item]) },
      { key: 'cut', label: t('cut'), icon: 'cut-outline', onPress: () => doCut([item]) },
    );
    if (item.isDir) {
      actions.push({
        key: 'update',
        label: t('updateFolder'),
        icon: 'refresh-outline',
        onPress: () => {
          setMenuItem(null);
          refresh();
        },
      });
    } else {
      actions.push({
        key: 'update',
        label: t('updateFile'),
        icon: 'swap-vertical-outline',
        onPress: () => startReplace(item),
      });
    }
    actions.push(
      { key: 'info', label: t('info'), icon: 'information-circle-outline', onPress: () => { setMenuItem(null); setInfoItem(item); } },
      { key: 'delete', label: t('delete'), icon: 'trash-outline', danger: true, onPress: () => { setMenuItem(null); setPending({ kind: 'delete', items: [item] }); } },
    );
    return actions;
  };

  const fabActions: SheetAction[] = [
    { key: 'folder', label: t('newFolder'), icon: 'folder-open-outline', onPress: () => { setFabOpen(false); setPrompt({ kind: 'folder' }); } },
    { key: 'import', label: t('importFiles'), icon: 'download-outline', onPress: () => { setFabOpen(false); doImport(); } },
    {
      key: 'paste',
      label: t('pasteHere'),
      icon: 'clipboard-outline',
      disabled: !clipboard,
      onPress: () => {
        setFabOpen(false);
        doPaste();
      },
    },
  ];

  /* ---------------------------------- UI ---------------------------------- */

  const showEmptyFilter = rows.length === 0 && (!!query.trim() || activeCategory !== 'all');

  const list = (
    <FlatList
      data={sortedRows}
      keyExtractor={(row) => row.item.path}
      extraData={selected}
      renderItem={({ item: row }) => (
        <ItemRow
          item={row.item}
          category={categoryOf(row.item)}
          subtitle={row.subtitle}
          selectionMode={selectionMode}
          selected={selected.includes(row.item.path)}
          onPress={() => {
            if (selectionMode) toggleSelect(row.item.path);
            else if (row.item.isDir) navigate(row.item.path);
            else setMenuItem(row.item);
          }}
          onLongPress={() => enterSelection(row.item)}
          onMore={() => (selectionMode ? toggleSelect(row.item.path) : setMenuItem(row.item))}
        />
      )}
      ItemSeparatorComponent={null}
      refreshControl={<RefreshControl refreshing={loading} onRefresh={refresh} tintColor={palette.accent} />}
      contentContainerStyle={{ paddingBottom: insets.bottom + 180 }}
      ListEmptyComponent={
        showEmptyFilter ? (
          <EmptyView icon="search-outline" title={t('noResults')} hint={t('noResultsHint')} />
        ) : (
          <EmptyView
            icon="folder-open-outline"
            title={t('emptyFolder')}
            hint={t('emptyFolderHint')}
            actionLabel={t('newFolder')}
            onAction={() => setPrompt({ kind: 'folder' })}
          />
        )
      }
    />
  );

  const errorView = (
    <View style={styles.centered}>
      <EmptyView
        icon="lock-closed-outline"
        title={t('accessDenied')}
        hint={t('accessDeniedHint')}
        actionLabel={t('createRoot')}
        onAction={() => setPending({ kind: 'createRoot' })}
      />
      <View style={[styles.errorActions, { flexDirection: isRTL ? 'row-reverse' : 'row' }]}>
        <TouchableOpacity
          style={[styles.errorBtn, { backgroundColor: palette.surfaceAlt }]}
          onPress={refresh}
        >
          <Ionicons name="refresh" size={16} color={palette.text} />
          <Text style={[styles.errorBtnLabel, { color: palette.text }]}>{t('retry')}</Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={[styles.errorBtn, { backgroundColor: palette.accent }]}
          onPress={switchToSandbox}
        >
          <Ionicons name="shield-checkmark-outline" size={16} color={palette.accentContrast} />
          <Text style={[styles.errorBtnLabel, { color: palette.accentContrast }]}>{t('useSafeMode')}</Text>
        </TouchableOpacity>
      </View>
    </View>
  );

  return (
    <View style={[styles.root, { backgroundColor: palette.bg }]}>
      {/* Header */}
      <View
        style={[
          styles.header,
          {
            paddingTop: insets.top + SP.sm,
            backgroundColor: palette.bg,
            flexDirection: isRTL ? 'row-reverse' : 'row',
          },
        ]}
      >
        <View style={{ flex: 1 }}>
          <Text style={[styles.title, { color: palette.text, textAlign: isRTL ? 'right' : 'left' }]}>
            Virtual USB
          </Text>
          <Text style={[styles.subtitle, { color: palette.textDim, textAlign: isRTL ? 'right' : 'left' }]}>
            {`${t('storage')}: ${formatBytes(space.free)} ${t('free')} ${t('of')} ${formatBytes(space.total)}`}
          </Text>
        </View>
        <HeaderButton icon="refresh-outline" onPress={refresh} />
        <HeaderButton icon="swap-vertical-outline" onPress={() => setSortOpen(true)} />
        <HeaderButton icon="settings-outline" onPress={onOpenSettings} />
      </View>

      {/* Search */}
      <View style={[styles.searchRow, { flexDirection: isRTL ? 'row-reverse' : 'row' }]}>
        <View
          style={[
            styles.searchBox,
            { backgroundColor: palette.surfaceAlt, flexDirection: isRTL ? 'row-reverse' : 'row' },
          ]}
        >
          <Ionicons name="search-outline" size={16} color={palette.textFaint} />
          <TextInput
            value={query}
            onChangeText={setQuery}
            placeholder={t('searchHint')}
            placeholderTextColor={palette.textFaint}
            style={[styles.searchInput, { color: palette.text, textAlign: isRTL ? 'right' : 'left' }]}
            returnKeyType="search"
            autoCorrect={false}
          />
          {query ? (
            <TouchableOpacity onPress={() => setQuery('')}>
              <Ionicons name="close-circle" size={16} color={palette.textFaint} />
            </TouchableOpacity>
          ) : null}
        </View>
        <TouchableOpacity
          onPress={() => updateSettings({ recursive: !settings.recursive })}
          style={[
            styles.recursiveBtn,
            { backgroundColor: settings.recursive ? palette.accent : palette.surfaceAlt },
          ]}
        >
          <Ionicons
            name="git-network-outline"
            size={17}
            color={settings.recursive ? palette.accentContrast : palette.textDim}
          />
        </TouchableOpacity>
      </View>

      <PathBar crumbs={crumbs} onNavigate={navigate} canGoUp={cwd !== settings.root} onGoUp={goUp} />

      <CategoryBar
        categories={categories}
        counts={counts}
        active={activeCategory}
        total={settings.recursive ? deepItems.length : items.length}
        onChange={setActiveCategory}
      />

      {loading && items.length === 0 ? (
        <View style={styles.centered}>
          <ActivityIndicator color={palette.accent} />
        </View>
      ) : accessError ? (
        errorView
      ) : (
        list
      )}

      {/* Clipboard bar */}
      {clipboard ? (
        <View
          style={[
            styles.clipBar,
            {
              bottom: insets.bottom + (selectionMode ? 74 : 16),
              backgroundColor: palette.surface,
              borderColor: palette.border,
              flexDirection: isRTL ? 'row-reverse' : 'row',
            },
          ]}
        >
          <Ionicons
            name={clipboard.mode === 'cut' ? 'cut-outline' : 'copy-outline'}
            size={18}
            color={palette.accent}
          />
          <Text style={[styles.clipText, { color: palette.text, textAlign: isRTL ? 'right' : 'left' }]}>
            {t('clipboardBar', {
              mode: clipboard.mode === 'cut' ? t('clipboardModeCut') : t('clipboardModeCopy'),
              n: clipboard.items.length,
            })}
          </Text>
          <TouchableOpacity style={[styles.clipBtn, { backgroundColor: palette.accent }]} onPress={doPaste}>
            <Text style={[styles.clipBtnLabel, { color: palette.accentContrast }]}>{t('pasteHere')}</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.clipClose} onPress={() => setClipboard(null)}>
            <Ionicons name="close" size={18} color={palette.textDim} />
          </TouchableOpacity>
        </View>
      ) : null}

      {/* Selection bar */}
      {selectionMode ? (
        <View
          style={[
            styles.selectionBar,
            {
              bottom: insets.bottom + 16,
              backgroundColor: palette.surface,
              borderColor: palette.border,
              flexDirection: isRTL ? 'row-reverse' : 'row',
            },
          ]}
        >
          <Text style={[styles.selectionCount, { color: palette.text }]}>
            {t('selectedCount', { n: selected.length })}
          </Text>
          <ToolbarButton icon="copy-outline" onPress={() => doCopy(selectedItems)} />
          <ToolbarButton icon="cut-outline" onPress={() => doCut(selectedItems)} />
          {selectedItems.length === 1 ? (
            <>
              <ToolbarButton
                icon="create-outline"
                onPress={() => setPrompt({ kind: 'rename', item: selectedItems[0] })}
              />
              <ToolbarButton icon="information-circle-outline" onPress={() => setInfoItem(selectedItems[0])} />
            </>
          ) : null}
          <ToolbarButton icon="layers-outline" onPress={selectAllVisible} />
          <ToolbarButton
            icon="trash-outline"
            color={palette.danger}
            onPress={() => setPending({ kind: 'delete', items: selectedItems })}
          />
          <ToolbarButton icon="close" onPress={exitSelection} />
        </View>
      ) : null}

      {/* FAB */}
      {!selectionMode ? (
        <TouchableOpacity
          style={[
            styles.fab,
            {
              bottom: insets.bottom + (clipboard ? 78 : 20),
              backgroundColor: palette.accent,
              [isRTL ? 'left' : 'right']: 20,
            } as never,
          ]}
          onPress={() => setFabOpen(true)}
        >
          <Ionicons name="add" size={28} color={palette.accentContrast} />
        </TouchableOpacity>
      ) : null}

      {/* Sheets */}
      <ActionMenuDialog
        visible={!!menuItem}
        title={menuItem?.name ?? ''}
        actions={menuItem ? itemActions(menuItem) : []}
        onClose={() => setMenuItem(null)}
      />

      <ActionMenuDialog
        visible={fabOpen}
        title={t('more')}
        actions={fabActions}
        onClose={() => setFabOpen(false)}
      />

      <Sheet visible={sortOpen} onClose={() => setSortOpen(false)} title={t('sortTitle')}>
        <View style={{ paddingHorizontal: SP.lg, paddingBottom: SP.md }}>
          {(['name', 'size', 'date', 'type'] as const).map((key) => (
            <TouchableOpacity
              key={key}
              style={[styles.sortRow, { flexDirection: isRTL ? 'row-reverse' : 'row' }]}
              onPress={() => updateSettings({ sortKey: key })}
            >
              <Text style={[styles.sortLabel, { color: palette.text, textAlign: isRTL ? 'right' : 'left' }]}>
                {t(key === 'name' ? 'sortName' : key === 'size' ? 'sortSize' : key === 'date' ? 'sortDate' : 'sortType')}
              </Text>
              {settings.sortKey === key ? (
                <Ionicons name="checkmark" size={18} color={palette.accent} />
              ) : null}
            </TouchableOpacity>
          ))}
          <TouchableOpacity
            style={[styles.sortRow, { flexDirection: isRTL ? 'row-reverse' : 'row', marginTop: SP.sm }]}
            onPress={() => updateSettings({ sortDir: settings.sortDir === 'asc' ? 'desc' : 'asc' })}
          >
            <Text style={[styles.sortLabel, { color: palette.text, textAlign: isRTL ? 'right' : 'left' }]}>
              {settings.sortDir === 'asc' ? t('asc') : t('desc')}
            </Text>
            <Ionicons
              name={settings.sortDir === 'asc' ? 'arrow-up-outline' : 'arrow-down-outline'}
              size={18}
              color={palette.accent}
            />
          </TouchableOpacity>
          <TouchableOpacity
            style={[styles.sortRow, { flexDirection: isRTL ? 'row-reverse' : 'row' }]}
            onPress={() => updateSettings({ foldersFirst: !settings.foldersFirst })}
          >
            <Text style={[styles.sortLabel, { color: palette.text, textAlign: isRTL ? 'right' : 'left' }]}>
              {t('foldersFirst')}
            </Text>
            <Ionicons
              name={settings.foldersFirst ? 'checkmark-circle' : 'ellipse-outline'}
              size={18}
              color={settings.foldersFirst ? palette.accent : palette.textFaint}
            />
          </TouchableOpacity>
        </View>
      </Sheet>

      <InfoSheet
        visible={!!infoItem}
        item={infoItem}
        category={infoItem ? categoryOf(infoItem) : null}
        onClose={() => setInfoItem(null)}
        onShare={infoItem && !infoItem.isDir ? () => { setInfoItem(null); doShare(infoItem); } : undefined}
      />

      <PromptDialog
        visible={prompt?.kind === 'folder'}
        title={t('newFolderTitle')}
        placeholder={t('newFolderPlaceholder')}
        confirmLabel={t('add')}
        onSubmit={doCreateFolder}
        onCancel={() => setPrompt(null)}
      />

      <PromptDialog
        visible={prompt?.kind === 'rename'}
        title={t('renameTitle')}
        placeholder={t('renamePlaceholder')}
        initialValue={prompt?.kind === 'rename' ? prompt.item.name : ''}
        confirmLabel={t('save')}
        onSubmit={(value) => {
          if (prompt?.kind === 'rename') doRename(prompt.item, value);
        }}
        onCancel={() => setPrompt(null)}
      />

      <ConfirmDialog
        visible={pending?.kind === 'delete'}
        title={
          pending?.kind === 'delete'
            ? pending.items.length === 1
              ? t('confirmDelete', { name: pending.items[0].name })
              : t('confirmDeleteMany', { n: pending.items.length })
            : ''
        }
        message={
          pending?.kind === 'delete'
            ? pending.items.length === 1
              ? pending.items[0].isDir
                ? t('confirmDeleteHintDir')
                : t('confirmDeleteHintFile')
              : t('confirmDeleteHintMany')
            : undefined
        }
        confirmLabel={t('delete')}
        danger
        onConfirm={() => {
          if (pending?.kind === 'delete') doDelete(pending.items);
        }}
        onCancel={() => setPending(null)}
      />

      <ConfirmDialog
        visible={pending?.kind === 'replace'}
        title={pending?.kind === 'replace' ? t('confirmReplace', { name: pending.item.name }) : ''}
        message={t('confirmReplaceHint')}
        confirmLabel={t('updateFile')}
        onConfirm={doReplace}
        onCancel={() => {
          setPending(null);
          setReplaceUri(null);
        }}
      />

      <ConfirmDialog
        visible={pending?.kind === 'createRoot'}
        title={t('createRoot')}
        message={`${settings.root}`}
        confirmLabel={t('add')}
        onConfirm={doCreateRoot}
        onCancel={() => setPending(null)}
      />
    </View>
  );
}

/* ----------------------------- small helpers ----------------------------- */

function HeaderButton({
  icon,
  onPress,
}: {
  icon: React.ComponentProps<typeof Ionicons>['name'];
  onPress: () => void;
}) {
  const { palette } = useApp();
  return (
    <TouchableOpacity onPress={onPress} style={styles.headerBtn} hitSlop={6}>
      <Ionicons name={icon} size={20} color={palette.text} />
    </TouchableOpacity>
  );
}

function ToolbarButton({
  icon,
  onPress,
  color,
}: {
  icon: React.ComponentProps<typeof Ionicons>['name'];
  onPress: () => void;
  color?: string;
}) {
  const { palette } = useApp();
  return (
    <TouchableOpacity onPress={onPress} style={styles.toolBtn}>
      <Ionicons name={icon} size={19} color={color ?? palette.text} />
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1 },
  header: { alignItems: 'center', paddingHorizontal: SP.lg, paddingBottom: SP.sm },
  title: { fontSize: 20, fontWeight: '800' },
  subtitle: { fontSize: 11, marginTop: 2 },
  headerBtn: { padding: SP.sm, marginLeft: 2, marginRight: 2 },
  searchRow: { alignItems: 'center', paddingHorizontal: SP.lg, paddingBottom: SP.sm, gap: SP.sm },
  searchBox: {
    flex: 1,
    alignItems: 'center',
    borderRadius: RADIUS.md,
    paddingHorizontal: SP.md,
    paddingVertical: 8,
    gap: SP.sm,
  },
  searchInput: { flex: 1, fontSize: 15, paddingVertical: 0 },
  recursiveBtn: { width: 42, height: 42, borderRadius: RADIUS.md, alignItems: 'center', justifyContent: 'center' },
  centered: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  errorActions: { gap: SP.md, paddingHorizontal: SP.xl, paddingBottom: SP.xl },
  errorBtn: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 6,
    paddingVertical: 12,
    borderRadius: RADIUS.md,
  },
  errorBtnLabel: { fontSize: 13, fontWeight: '700' },
  clipBar: {
    position: 'absolute',
    left: 16,
    right: 16,
    alignItems: 'center',
    gap: SP.sm,
    paddingVertical: 10,
    paddingHorizontal: SP.md,
    borderRadius: RADIUS.lg,
    borderWidth: 1,
    shadowOpacity: 0.2,
    shadowRadius: 10,
    shadowOffset: { width: 0, height: 4 },
    elevation: 6,
  },
  clipText: { flex: 1, fontSize: 13, fontWeight: '600' },
  clipBtn: { paddingHorizontal: SP.md, paddingVertical: 7, borderRadius: RADIUS.pill },
  clipBtnLabel: { fontSize: 12, fontWeight: '800' },
  clipClose: { padding: 4 },
  selectionBar: {
    position: 'absolute',
    left: 16,
    right: 16,
    alignItems: 'center',
    paddingVertical: 8,
    paddingHorizontal: SP.sm,
    borderRadius: RADIUS.lg,
    borderWidth: 1,
    shadowOpacity: 0.2,
    shadowRadius: 10,
    shadowOffset: { width: 0, height: 4 },
    elevation: 6,
  },
  selectionCount: { fontSize: 12, fontWeight: '700', paddingHorizontal: SP.sm },
  toolBtn: { paddingHorizontal: 9, paddingVertical: 6 },
  fab: {
    position: 'absolute',
    width: 58,
    height: 58,
    borderRadius: 29,
    alignItems: 'center',
    justifyContent: 'center',
    shadowOpacity: 0.3,
    shadowRadius: 12,
    shadowOffset: { width: 0, height: 6 },
    elevation: 8,
  },
  sortRow: {
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: 13,
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: 'rgba(125,125,125,0.15)',
  },
  sortLabel: { fontSize: 15, fontWeight: '600' },
});

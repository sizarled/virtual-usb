/** Human readable formatting helpers (no Intl dependency — works everywhere in Hermes). */

export function formatBytes(bytes?: number | null, decimals = 1): string {
  if (bytes === null || bytes === undefined || Number.isNaN(bytes)) return '—';
  if (bytes < 0) return '—';
  if (bytes < 1024) return `${bytes} B`;
  const units = ['KB', 'MB', 'GB', 'TB', 'PB'];
  let value = bytes / 1024;
  let unitIndex = 0;
  while (value >= 1024 && unitIndex < units.length - 1) {
    value /= 1024;
    unitIndex += 1;
  }
  const digits = value >= 100 || unitIndex === 0 ? 0 : decimals;
  return `${value.toFixed(digits)} ${units[unitIndex]}`;
}

const AR_MONTHS = [
  'يناير',
  'فبراير',
  'مارس',
  'أبريل',
  'ماي',
  'يونيو',
  'يوليوز',
  'غشت',
  'شتنبر',
  'أكتوبر',
  'نونبر',
  'دجنبر',
];
const EN_MONTHS = [
  'Jan',
  'Feb',
  'Mar',
  'Apr',
  'May',
  'Jun',
  'Jul',
  'Aug',
  'Sep',
  'Oct',
  'Nov',
  'Dec',
];

const pad2 = (n: number) => (n < 10 ? '0' + n : String(n));

/** "14 مارس 2026" / "14 Mar 2026" */
export function formatDate(ms?: number | null, lang: 'ar' | 'en' = 'en'): string {
  if (!ms || Number.isNaN(ms)) return '—';
  const d = new Date(ms);
  const months = lang === 'ar' ? AR_MONTHS : EN_MONTHS;
  return `${d.getDate()} ${months[d.getMonth()]} ${d.getFullYear()}`;
}

/** "14 مارس 2026، 15:07" */
export function formatDateTime(ms?: number | null, lang: 'ar' | 'en' = 'en'): string {
  if (!ms || Number.isNaN(ms)) return '—';
  const d = new Date(ms);
  const sep = lang === 'ar' ? '، ' : ', ';
  return `${formatDate(ms, lang)}${sep}${pad2(d.getHours())}:${pad2(d.getMinutes())}`;
}

/** Compact "قبل 5 دقائق" style, used in file rows. */
export function formatRelative(ms?: number | null, lang: 'ar' | 'en' = 'en'): string {
  if (!ms || Number.isNaN(ms)) return '—';
  const diff = Date.now() - ms;
  const abs = Math.abs(diff);
  const min = 60_000;
  const hour = 60 * min;
  const day = 24 * hour;
  if (abs < min) return lang === 'ar' ? 'الآن' : 'just now';
  if (abs < hour) {
    const n = Math.round(abs / min);
    return lang === 'ar' ? `قبل ${n} د` : `${n}m ago`;
  }
  if (abs < day) {
    const n = Math.round(abs / hour);
    return lang === 'ar' ? `قبل ${n} س` : `${n}h ago`;
  }
  if (abs < 7 * day) {
    const n = Math.round(abs / day);
    return lang === 'ar' ? `قبل ${n} يوم` : `${n}d ago`;
  }
  return formatDate(ms, lang);
}

/** Normalize a user typed extension: strip dots/spaces, lowercase. */
export function cleanExtension(input: string): string {
  return input.trim().toLowerCase().replace(/^\.+/, '').replace(/\s+/g, '');
}

export function pluralize(count: number, lang: 'ar' | 'en', ar: [string, string, string]): string {
  if (lang === 'en') return count === 1 ? ar[0] : ar[1];
  if (count === 1) return ar[0];
  if (count === 2) return ar[2] || ar[1];
  return ar[1];
}

import { Directory, File, Paths } from 'expo-file-system';

import { basename, dirname, extname, fileUri, joinPath, normalizePath, uriToPath } from './paths';

export type FsItem = {
  /** Absolute POSIX path */
  path: string;
  name: string;
  isDir: boolean;
  /** lowercase extension without the dot ("" for folders / no extension) */
  ext: string;
  /** bytes — always 0 for folders (compute on demand with dirSize) */
  size: number;
  mtime: number | null;
  ctime: number | null;
  mime: string;
};

export type PathInfo = { exists: boolean; isDirectory: boolean };

export type WalkResult = {
  /** relative dir paths, shallow first */
  dirs: string[];
  /** relative file paths */
  files: string[];
};

export type ProgressInfo = { done: number; total: number; current: string };
export type ProgressFn = (info: ProgressInfo) => void;

const tick = () => new Promise<void>((resolve) => setTimeout(resolve, 0));
const isDirectoryInstance = (entry: unknown): entry is Directory =>
  typeof (entry as Directory | undefined)?.list === 'function';

/* ------------------------------------------------------------------ *
 * Basic info
 * ------------------------------------------------------------------ */

export function pathInfo(path: string): PathInfo {
  try {
    const info = Paths.info(fileUri(path));
    return { exists: !!info?.exists, isDirectory: !!info?.isDirectory };
  } catch {
    return { exists: false, isDirectory: false };
  }
}

export function exists(path: string): boolean {
  return pathInfo(path).exists;
}

export function isDirectory(path: string): boolean {
  return pathInfo(path).isDirectory;
}

/* ------------------------------------------------------------------ *
 * Listing
 * ------------------------------------------------------------------ */

/** Throws when the directory is missing or not readable. */
export function listDirectory(path: string): FsItem[] {
  const dir = new Directory(fileUri(path));
  if (!dir.exists) throw new Error('NO_ACCESS');
  const raw = dir.list();
  const items: FsItem[] = [];
  for (const entry of raw) {
    const p = uriToPath(entry.uri);
    const name = basename(p);
    if (!name) continue;
    const isDir = isDirectoryInstance(entry);
    let size = 0;
    let mtime: number | null = null;
    let ctime: number | null = null;
    let mime = '';
    try {
      if (isDir) {
        const info = entry.info();
        mtime = info?.modificationTime ?? null;
        ctime = info?.creationTime ?? null;
      } else {
        size = entry.size ?? 0;
        mtime = entry.modificationTime ?? null;
        ctime = entry.creationTime ?? null;
        mime = entry.type ?? '';
      }
    } catch {
      /* unreadable entry — keep defaults */
    }
    items.push({ path: p, name, isDir, ext: isDir ? '' : extname(p), size, mtime, ctime, mime });
  }
  return items;
}

/** Walk a directory tree. Returns paths relative to `path`. */
export function walk(path: string, max = 20000): WalkResult {
  const dirs: string[] = [];
  const files: string[] = [];
  const stack: { abs: string; rel: string }[] = [{ abs: path, rel: '' }];
  while (stack.length) {
    const node = stack.pop()!;
    let entries;
    try {
      entries = listDirectory(node.abs);
    } catch {
      continue;
    }
    for (const entry of entries) {
      if (dirs.length + files.length >= max) return { dirs, files };
      const rel = node.rel ? `${node.rel}/${entry.name}` : entry.name;
      if (entry.isDir) {
        dirs.push(rel);
        stack.push({ abs: entry.path, rel });
      } else {
        files.push(rel);
      }
    }
  }
  return { dirs, files };
}

export async function countItems(path: string): Promise<number> {
  await tick();
  const { dirs, files } = walk(path);
  return dirs.length + files.length;
}

/** Flat list of every file inside `path` (recursive), with its relative path. */
export function walkItems(root: string, max = 5000): { rel: string; item: FsItem }[] {
  const out: { rel: string; item: FsItem }[] = [];
  const stack: { abs: string; rel: string }[] = [{ abs: root, rel: '' }];
  while (stack.length) {
    const node = stack.pop()!;
    let entries: FsItem[];
    try {
      entries = listDirectory(node.abs);
    } catch {
      continue;
    }
    for (const entry of entries) {
      const rel = node.rel ? `${node.rel}/${entry.name}` : entry.name;
      if (entry.isDir) stack.push({ abs: entry.path, rel });
      else out.push({ rel, item: entry });
      if (out.length >= max) return out;
    }
  }
  return out;
}

/** Copy a file coming from a picker (file:// URI or plain path) into a plain path. */
export function copyUriToPath(srcUri: string, destPath: string): void {
  const uri = /^[a-z][a-z0-9+.-]*:/i.test(srcUri) ? srcUri : fileUri(srcUri);
  new File(uri).copy(new File(fileUri(destPath)));
}

/** Recursive size of a folder. Yields to the event loop so the UI keeps breathing. */
export async function dirSize(
  path: string,
  cap = 20000,
): Promise<{ size: number; files: number; folders: number; truncated: boolean }> {
  let size = 0;
  let files = 0;
  let folders = 0;
  let truncated = false;
  const stack: string[] = [path];
  while (stack.length) {
    const current = stack.pop()!;
    let entries: FsItem[];
    try {
      entries = listDirectory(current);
    } catch {
      continue;
    }
    for (const entry of entries) {
      if (entry.isDir) {
        folders += 1;
        stack.push(entry.path);
      } else {
        files += 1;
        size += entry.size;
        if (files % 400 === 0) await tick();
      }
      if (files + folders >= cap) {
        truncated = true;
        return { size, files, folders, truncated };
      }
    }
  }
  return { size, files, folders, truncated };
}

/* ------------------------------------------------------------------ *
 * Create / delete
 * ------------------------------------------------------------------ */

export function createDirectory(path: string): void {
  new Directory(fileUri(path)).create({ intermediates: true, idempotent: true });
}

export function removeFile(path: string): void {
  new File(fileUri(path)).delete();
}

/** Recursive delete (folders included). Returns the number of deleted nodes. */
export async function removePath(path: string, onProgress?: ProgressFn): Promise<number> {
  const info = pathInfo(path);
  if (!info.exists) return 0;
  if (!info.isDirectory) {
    removeFile(path);
    return 1;
  }
  const { dirs, files } = walk(path);
  const total = dirs.length + files.length + 1;
  let done = 0;
  for (const rel of files) {
    try {
      removeFile(joinPath(path, rel));
    } catch {
      /* best effort */
    }
    done += 1;
    if (done % 25 === 0) {
      onProgress?.({ done, total, current: rel });
      await tick();
    }
  }
  for (let i = dirs.length - 1; i >= 0; i -= 1) {
    try {
      new Directory(fileUri(joinPath(path, dirs[i]))).delete();
    } catch {
      /* best effort */
    }
    done += 1;
    if (done % 25 === 0) {
      onProgress?.({ done, total, current: dirs[i] });
      await tick();
    }
  }
  new Directory(fileUri(path)).delete();
  onProgress?.({ done: total, total, current: basename(path) });
  return total;
}

/* ------------------------------------------------------------------ *
 * Copy / move / rename
 * ------------------------------------------------------------------ */

export function copyFile(src: string, dest: string): void {
  new File(fileUri(src)).copy(new File(fileUri(dest)));
}

/** Recursive copy. `dest` must not exist yet. */
export async function copyPath(src: string, dest: string, onProgress?: ProgressFn): Promise<void> {
  const info = pathInfo(src);
  if (!info.exists) throw new Error('SOURCE_MISSING');
  if (!info.isDirectory) {
    copyFile(src, dest);
    onProgress?.({ done: 1, total: 1, current: basename(src) });
    return;
  }
  const { dirs, files } = walk(src);
  const total = dirs.length + files.length + 1;
  createDirectory(dest);
  let done = 1;
  onProgress?.({ done, total, current: basename(dest) });
  for (const rel of dirs) {
    createDirectory(joinPath(dest, rel));
    done += 1;
    if (done % 20 === 0) {
      onProgress?.({ done, total, current: rel });
      await tick();
    }
  }
  for (const rel of files) {
    copyFile(joinPath(src, rel), joinPath(dest, rel));
    done += 1;
    if (done % 10 === 0) {
      onProgress?.({ done, total, current: rel });
      await tick();
    }
  }
  onProgress?.({ done: total, total, current: basename(dest) });
}

/** Native move first (fast, atomic); falls back to copy + delete. */
export async function movePath(src: string, dest: string, onProgress?: ProgressFn): Promise<void> {
  const info = pathInfo(src);
  if (!info.exists) throw new Error('SOURCE_MISSING');
  try {
    if (info.isDirectory) {
      new Directory(fileUri(src)).move(new Directory(fileUri(dest)));
    } else {
      new File(fileUri(src)).move(new File(fileUri(dest)));
    }
    onProgress?.({ done: 1, total: 1, current: basename(dest) });
    return;
  } catch {
    /* fall through to copy + delete */
  }
  await copyPath(src, dest, onProgress);
  await removePath(src);
}

export function renamePath(path: string, newName: string): void {
  const target = joinPath(dirname(path), newName);
  if (normalizePath(target) === normalizePath(path)) return;
  try {
    if (pathInfo(path).isDirectory) {
      new Directory(fileUri(path)).rename(newName);
    } else {
      new File(fileUri(path)).rename(newName);
    }
    return;
  } catch {
    /* fall back to copy + delete */
  }
  if (pathInfo(path).isDirectory) {
    createDirectory(target);
    const { dirs, files } = walk(path);
    for (const rel of dirs) createDirectory(joinPath(target, rel));
    for (const rel of files) copyFile(joinPath(path, rel), joinPath(target, rel));
    new Directory(fileUri(path)).delete();
  } else {
    copyFile(path, target);
    removeFile(path);
  }
}

/** "name (2).ext" style collision avoidance. */
export function uniquePath(parent: string, name: string): string {
  let candidate = joinPath(parent, name);
  if (!exists(candidate)) return candidate;
  const dot = name.lastIndexOf('.');
  const stem = dot > 0 ? name.slice(0, dot) : name;
  const ext = dot > 0 ? name.slice(dot) : '';
  let n = 2;
  while (n < 10000) {
    candidate = joinPath(parent, `${stem} (${n})${ext}`);
    if (!exists(candidate)) return candidate;
    n += 1;
  }
  return joinPath(parent, `${stem} (${Date.now()})${ext}`);
}

/* ------------------------------------------------------------------ *
 * Details
 * ------------------------------------------------------------------ */

export type FileDetails = {
  exists: boolean;
  isDir: boolean;
  size: number | null;
  mtime: number | null;
  ctime: number | null;
  mime: string;
  md5: string | null;
};

export function details(path: string, withMd5 = false): FileDetails {
  const result: FileDetails = {
    exists: false,
    isDir: false,
    size: null,
    mtime: null,
    ctime: null,
    mime: '',
    md5: null,
  };
  try {
    const info = pathInfo(path);
    result.exists = info.exists;
    result.isDir = info.isDirectory;
    if (!info.exists) return result;
    if (info.isDirectory) {
      const d = new Directory(fileUri(path)).info();
      result.size = d?.size ?? null;
      result.mtime = d?.modificationTime ?? null;
      result.ctime = d?.creationTime ?? null;
    } else {
      const f = new File(fileUri(path));
      result.size = f.size;
      result.mtime = f.modificationTime;
      result.ctime = f.creationTime;
      result.mime = f.type ?? '';
      if (withMd5) {
        try {
          result.md5 = f.md5 ?? null;
        } catch {
          result.md5 = null;
        }
      }
    }
  } catch {
    /* ignore */
  }
  return result;
}

export function diskSpace(): { total: number; free: number } {
  try {
    return { total: Number(Paths.totalDiskSpace) || 0, free: Number(Paths.availableDiskSpace) || 0 };
  } catch {
    return { total: 0, free: 0 };
  }
}

/** Human readable message for a thrown filesystem error. */
export function describeFsError(error: unknown, t: (key: string) => string): string {
  const raw = error instanceof Error ? error.message : String(error);
  if (raw === 'NO_ACCESS' || /denied|permission|not permitted/i.test(raw)) return t('errPermission');
  if (raw === 'SOURCE_MISSING' || /does not exist|no such file/i.test(raw)) return t('errMissing');
  if (/already exists|exists/i.test(raw)) return t('errExists');
  if (/read-only|readonly/i.test(raw)) return t('errReadOnly');
  if (/space|full/i.test(raw)) return t('errNoSpace');
  return raw || t('errUnknown');
}

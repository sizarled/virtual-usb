/**
 * Path helpers — pure string utilities (no filesystem access).
 * All paths inside the app are plain POSIX absolute paths, e.g. "/general_storage/a/b.mp3".
 * expo-file-system (SDK 54+) File/Directory classes need file:// URIs, so we convert
 * at the boundary with fileUri() / uriToPath().
 */

/** Collapse duplicate slashes, resolve "." and "..", guarantee a leading slash, strip trailing slash. */
export function normalizePath(input: string): string {
  if (!input) return '/';
  let raw = input.replace(/\\/g, '/');
  if (!raw.startsWith('/')) raw = '/' + raw;
  const stack: string[] = [];
  for (const part of raw.split('/')) {
    if (!part || part === '.') continue;
    if (part === '..') {
      stack.pop();
      continue;
    }
    stack.push(part);
  }
  return '/' + stack.join('/');
}

/** Join path segments safely. */
export function joinPath(base: string, ...segments: string[]): string {
  return normalizePath([base, ...segments].join('/'));
}

/** Last path component. "/" -> "" */
export function basename(path: string): string {
  const p = normalizePath(path);
  if (p === '/') return '';
  return p.slice(p.lastIndexOf('/') + 1);
}

/** Parent path. Parent of "/" is "/" and parent of "/a" is "/". */
export function dirname(path: string): string {
  const p = normalizePath(path);
  if (p === '/') return '/';
  const i = p.lastIndexOf('/');
  return i <= 0 ? '/' : p.slice(0, i);
}

/** Lowercase extension without the dot. "" when there is none. */
export function extname(path: string): string {
  const name = basename(path);
  const i = name.lastIndexOf('.');
  if (i <= 0 || i === name.length - 1) return '';
  return name.slice(i + 1).toLowerCase();
}

/** Relative path of `path` inside `root`, or "" if it is not inside. */
export function relativeTo(root: string, path: string): string {
  const r = normalizePath(root);
  const p = normalizePath(path);
  if (p === r) return '';
  if (!p.startsWith(r === '/' ? '/' : r + '/')) return '';
  return p.slice(r.length).replace(/^\//, '');
}

/** True when `path` is `root` or lives under it. */
export function isInside(root: string, path: string): boolean {
  const r = normalizePath(root);
  const p = normalizePath(path);
  if (p === r) return true;
  return p.startsWith(r === '/' ? '/' : r + '/');
}

/** Split "/a/b/c" into crumbs: [{path:'/',name:'/'} ,{path:'/a',name:'a'}, ...] */
export function breadcrumbs(path: string, rootLabel = '/'): { path: string; name: string }[] {
  const p = normalizePath(path);
  const parts = p.split('/').filter(Boolean);
  const crumbs: { path: string; name: string }[] = [{ path: '/', name: rootLabel }];
  let acc = '';
  for (const part of parts) {
    acc += '/' + part;
    crumbs.push({ path: acc, name: part });
  }
  return crumbs;
}

/** Percent-encode each segment and prefix the file:// scheme. */
export function fileUri(path: string): string {
  const p = normalizePath(path);
  const encoded = p
    .split('/')
    .map((seg) => encodeURIComponent(seg))
    .join('/');
  return 'file://' + encoded;
}

/** Reverse of fileUri(): "file:///a%20b" -> "/a b" */
export function uriToPath(uri: string): string {
  let s = uri;
  const scheme = s.indexOf('://');
  if (scheme !== -1) s = s.slice(scheme + 3);
  const q = s.indexOf('?');
  if (q !== -1) s = s.slice(0, q);
  const decoded = s
    .split('/')
    .map((seg) => {
      try {
        return decodeURIComponent(seg);
      } catch {
        return seg;
      }
    })
    .join('/');
  return normalizePath(decoded);
}

/** Characters that break iOS/HFS paths. */
export const INVALID_NAME_CHARS = /[\\/:*?"<>|]/;

export function isValidName(name: string): boolean {
  const trimmed = name.trim();
  if (!trimmed) return false;
  if (trimmed === '.' || trimmed === '..') return false;
  return !INVALID_NAME_CHARS.test(trimmed);
}

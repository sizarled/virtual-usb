import type { FsItem } from './fs';

export type Category = {
  id: string;
  /** Arabic display name (editable) */
  labelAr: string;
  /** English display name (editable) */
  labelEn: string;
  /** Ionicons glyph name */
  icon: string;
  /** Accent color (hex) */
  color: string;
  /** Extensions WITHOUT the dot, lowercase */
  exts: string[];
  /** The catch-all category (receives everything unmatched). Exactly one is allowed. */
  fallback?: boolean;
  /** Built-in categories can be edited but are restored by "reset defaults". */
  builtin?: boolean;
};

export const FALLBACK_CATEGORY_ID = 'files';

export const DEFAULT_CATEGORIES: Category[] = [
  {
    id: 'audio',
    labelAr: 'الصوتيات',
    labelEn: 'Audio',
    icon: 'musical-notes',
    color: '#FF5C8A',
    exts: [
      'mp3', 'wav', 'aac', 'flac', 'm4a', 'm4b', 'ogg', 'oga', 'opus', 'wma', 'aiff', 'aif',
      'aifc', 'alac', 'amr', 'caf', 'mka', 'mid', 'midi', 'ape', 'mp2', 'ra', 'au', 'weba',
    ],
    builtin: true,
  },
  {
    id: 'video',
    labelAr: 'الفيديوهات',
    labelEn: 'Videos',
    icon: 'videocam',
    color: '#7C6BFF',
    exts: [
      'mp4', 'm4v', 'mov', 'mkv', 'avi', 'webm', 'flv', 'wmv', '3gp', '3g2', 'mpeg', 'mpg',
      'mpe', 'm2ts', 'mts', 'ts', 'vob', 'rmvb', 'rm', 'ogv', 'hevc', 'm2v', 'divx', 'xvid',
      'asf', 'f4v', 'qt',
    ],
    builtin: true,
  },
  {
    id: 'apps',
    labelAr: 'التطبيقات',
    labelEn: 'Apps',
    icon: 'apps',
    color: '#00C2FF',
    exts: [
      'ipa', 'apk', 'aab', 'apks', 'apkm', 'xapk', 'deb', 'pkg', 'app', 'xap', 'appx',
      'msix', 'jar', 'jad', 'rpx', 'wgt', 'nsp', 'xci',
    ],
    builtin: true,
  },
  {
    id: 'images',
    labelAr: 'الصور',
    labelEn: 'Images',
    icon: 'images',
    color: '#2DD4A7',
    exts: [
      'jpg', 'jpeg', 'png', 'gif', 'webp', 'heic', 'heif', 'bmp', 'tif', 'tiff', 'svg', 'ico',
      'avif', 'raw', 'cr2', 'cr3', 'nef', 'arw', 'dng', 'orf', 'rw2', 'psd', 'xcf', 'eps', 'jfif',
    ],
    builtin: true,
  },
  {
    id: 'documents',
    labelAr: 'المستندات',
    labelEn: 'Documents',
    icon: 'document-text',
    color: '#FFB547',
    exts: [
      'pdf', 'epub', 'mobi', 'azw', 'azw3', 'kfx', 'djvu', 'fb2', 'ibooks', 'txt', 'text', 'md',
      'markdown', 'rtf', 'doc', 'docx', 'pages', 'odt', 'ott', 'xls', 'xlsx', 'numbers', 'ods',
      'csv', 'ppt', 'pptx', 'key', 'odp', 'note', 'enex', 'tex', 'log', 'json', 'xml', 'yaml',
      'yml', 'ini', 'conf', 'cfg', 'sql', 'html', 'htm', 'chm', 'xps', 'oxps', 'one', 'vcf', 'ics',
    ],
    builtin: true,
  },
  {
    id: 'files',
    labelAr: 'الملفات',
    labelEn: 'Files',
    icon: 'document',
    color: '#8A94A6',
    exts: [],
    fallback: true,
    builtin: true,
  },
  {
    id: 'archives',
    labelAr: 'المضغوطة',
    labelEn: 'Archives',
    icon: 'archive',
    color: '#FF7A45',
    exts: [
      'zip', 'rar', '7z', 'tar', 'gz', 'tgz', 'bz2', 'xz', 'lz', 'lzma', 'z', 'zipx', 'cab',
      'arj', 'lzh', 'iso', 'zst', 'tbz', 'txz', 'tar.gz', 'sit', 'sitx', 'zz', 'ace',
    ],
    builtin: true,
  },
];

export function categoryLabel(cat: Category, lang: 'ar' | 'en'): string {
  return lang === 'ar' ? cat.labelAr || cat.labelEn || cat.id : cat.labelEn || cat.labelAr || cat.id;
}

/** id of the catch-all category (falls back to FALLBACK_CATEGORY_ID). */
export function fallbackId(categories: Category[]): string {
  return categories.find((c) => c.fallback)?.id ?? FALLBACK_CATEGORY_ID;
}

const index = (categories: Category[]): Map<string, string> => {
  const map = new Map<string, string>();
  for (const cat of categories) {
    for (const ext of cat.exts) {
      const e = ext.toLowerCase();
      if (!e || map.has(e)) continue;
      map.set(e, cat.id);
    }
  }
  return map;
};

export function categoryIdForExtension(categories: Category[], ext: string): string {
  if (!ext) return fallbackId(categories);
  const e = ext.toLowerCase();
  // Longest match first so compound extensions like "tar.gz" win over "gz".
  const candidates = categories.filter((c) => c.exts.some((x) => x.toLowerCase() === e));
  if (candidates.length === 0) return fallbackId(categories);
  return candidates[0].id;
}

export function categoryForItem(categories: Category[], item: FsItem): Category {
  const id = item.isDir ? '' : categoryIdForExtension(categories, item.ext);
  return (
    categories.find((c) => c.id === id) ??
    categories.find((c) => c.id === fallbackId(categories)) ??
    categories[categories.length - 1]
  );
}

/** Build a lookup map once per render instead of scanning the list per row. */
export function categoryMap(categories: Category[]): Record<string, Category> {
  const map: Record<string, Category> = {};
  for (const c of categories) map[c.id] = c;
  return map;
}

export { index as categoryIndex };

let counter = 0;
export function newCategoryId(): string {
  counter += 1;
  return `custom_${Date.now().toString(36)}_${counter}`;
}

/** Icon + color palettes offered in the category editor. */
export const ICON_CHOICES: string[] = [
  'musical-notes', 'videocam', 'apps', 'images', 'document-text', 'document', 'archive',
  'book', 'newspaper', 'code-slash', 'file-tray-full', 'folder', 'briefcase', 'school',
  'game-controller', 'heart', 'star', 'flash', 'cloud', 'download', 'cube', 'color-palette',
  'hardware-chip', 'key', 'lock-closed', 'gift', 'cafe', 'airplane', 'car', 'fitness',
];

export const COLOR_CHOICES: string[] = [
  '#FF5C8A', '#7C6BFF', '#00C2FF', '#2DD4A7', '#FFB547', '#FF7A45', '#8A94A6',
  '#F45B69', '#22A7F0', '#A66DD4', '#00B8A9', '#F6C453', '#E8654B', '#5C6BC0',
];

import AsyncStorage from '@react-native-async-storage/async-storage';
import { Paths } from 'expo-file-system';
import * as Localization from 'expo-localization';
import React, {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
} from 'react';
import { useColorScheme } from 'react-native';

import { Lang, StrKey, translate } from '../i18n/strings';
import { Category, DEFAULT_CATEGORIES } from '../lib/categories';
import { uriToPath } from '../lib/paths';
import { Palette, palettes, ThemeMode } from '../theme';

export type SortKey = 'name' | 'size' | 'date' | 'type';

export type Settings = {
  /** The only folder the app is allowed to show. */
  root: string;
  lang: Lang | 'system';
  theme: ThemeMode;
  sortKey: SortKey;
  sortDir: 'asc' | 'desc';
  foldersFirst: boolean;
  /** Search / category filtering also scans subfolders */
  recursive: boolean;
  showHidden: boolean;
};

export type BusyState = { label: string; done?: number; total?: number };
export type ToastKind = 'info' | 'error' | 'success';
export type Toast = { message: string; kind: ToastKind };

const SETTINGS_KEY = 'vusb:settings:v1';
const CATEGORIES_KEY = 'vusb:categories:v1';

export const DEFAULT_SETTINGS: Settings = {
  root: '/general_storage',
  lang: 'system',
  theme: 'system',
  sortKey: 'name',
  sortDir: 'asc',
  foldersFirst: true,
  recursive: false,
  showHidden: false,
};

function sandboxRoot(): string {
  try {
    return uriToPath(Paths.document.uri) + '/general_storage';
  } catch {
    return '/general_storage';
  }
}

type AppContextValue = {
  ready: boolean;
  settings: Settings;
  updateSettings: (patch: Partial<Settings>) => void;
  categories: Category[];
  setCategories: (next: Category[] | ((prev: Category[]) => Category[])) => void;
  resetCategories: () => void;
  lang: Lang;
  isRTL: boolean;
  palette: Palette;
  t: (key: StrKey, vars?: Record<string, string | number>) => string;
  busy: BusyState | null;
  setBusy: (state: BusyState | null) => void;
  toast: Toast | null;
  showToast: (message: string, kind?: ToastKind) => void;
  hideToast: () => void;
  sandboxRoot: string;
};

const AppContext = createContext<AppContextValue | null>(null);

export function AppProvider({ children }: { children: React.ReactNode }) {
  const systemScheme = useColorScheme();
  const [ready, setReady] = useState(false);
  const [settings, setSettings] = useState<Settings>(DEFAULT_SETTINGS);
  const [categories, setCategoriesState] = useState<Category[]>(DEFAULT_CATEGORIES);
  const [busy, setBusy] = useState<BusyState | null>(null);
  const [toast, setToast] = useState<Toast | null>(null);
  const toastTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  // ---- load persisted state ----
  useEffect(() => {
    (async () => {
      try {
        const [rawSettings, rawCategories] = await Promise.all([
          AsyncStorage.getItem(SETTINGS_KEY),
          AsyncStorage.getItem(CATEGORIES_KEY),
        ]);
        if (rawSettings) {
          const parsed = JSON.parse(rawSettings) as Partial<Settings>;
          setSettings((prev) => ({ ...prev, ...parsed }));
        }
        if (rawCategories) {
          const parsedCats = JSON.parse(rawCategories) as Category[];
          if (Array.isArray(parsedCats) && parsedCats.length) setCategoriesState(parsedCats);
        }
      } catch {
        /* first launch or corrupted storage — defaults are fine */
      } finally {
        setReady(true);
      }
    })();
  }, []);

  const updateSettings = useCallback((patch: Partial<Settings>) => {
    setSettings((prev) => ({ ...prev, ...patch }));
  }, []);

  const setCategories = useCallback((next: Category[] | ((prev: Category[]) => Category[])) => {
    setCategoriesState((prev) => (typeof next === 'function' ? next(prev) : next));
  }, []);

  const resetCategories = useCallback(() => {
    setCategoriesState(DEFAULT_CATEGORIES.map((c) => ({ ...c, exts: [...c.exts] })));
  }, []);

  useEffect(() => {
    if (!ready) return;
    AsyncStorage.setItem(SETTINGS_KEY, JSON.stringify(settings)).catch(() => {});
  }, [settings, ready]);

  useEffect(() => {
    if (!ready) return;
    AsyncStorage.setItem(CATEGORIES_KEY, JSON.stringify(categories)).catch(() => {});
  }, [categories, ready]);

  const showToast = useCallback((message: string, kind: ToastKind = 'info') => {
    if (toastTimer.current) clearTimeout(toastTimer.current);
    setToast({ message, kind });
    toastTimer.current = setTimeout(() => setToast(null), 2800);
  }, []);

  const hideToast = useCallback(() => {
    if (toastTimer.current) clearTimeout(toastTimer.current);
    setToast(null);
  }, []);

  useEffect(() => () => {
    if (toastTimer.current) clearTimeout(toastTimer.current);
  }, []);

  // ---- resolved language / palette ----
  const systemLang: Lang = useMemo(() => {
    try {
      const locales = Localization.getLocales();
      const code = locales?.[0]?.languageCode?.toLowerCase();
      return code === 'ar' ? 'ar' : 'en';
    } catch {
      return 'en';
    }
  }, []);

  const lang: Lang = settings.lang === 'system' ? systemLang : settings.lang;
  const isRTL = lang === 'ar';

  const palette: Palette = useMemo(() => {
    const mode = settings.theme === 'system' ? systemScheme ?? 'dark' : settings.theme;
    return palettes[mode === 'light' ? 'light' : 'dark'];
  }, [settings.theme, systemScheme]);

  const t = useCallback(
    (key: StrKey, vars?: Record<string, string | number>) => translate(lang, key, vars),
    [lang],
  );

  const value = useMemo<AppContextValue>(
    () => ({
      ready,
      settings,
      updateSettings,
      categories,
      setCategories,
      resetCategories,
      lang,
      isRTL,
      palette,
      t,
      busy,
      setBusy,
      toast,
      showToast,
      hideToast,
      sandboxRoot: sandboxRoot(),
    }),
    [
      ready,
      settings,
      updateSettings,
      categories,
      setCategories,
      resetCategories,
      lang,
      isRTL,
      palette,
      t,
      busy,
      toast,
      showToast,
      hideToast,
    ],
  );

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
}

export function useApp(): AppContextValue {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error('useApp must be used inside <AppProvider>');
  return ctx;
}

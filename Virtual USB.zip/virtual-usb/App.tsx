import { StatusBar } from 'expo-status-bar';
import React, { useState } from 'react';
import { View } from 'react-native';
import { SafeAreaProvider } from 'react-native-safe-area-context';

import { BusyOverlay } from './src/components/Dialogs';
import { ToastView } from './src/components/Feedback';
import { BrowserScreen } from './src/screens/BrowserScreen';
import { SettingsScreen } from './src/screens/SettingsScreen';
import { AppProvider, useApp } from './src/state/AppContext';

function Shell() {
  const { palette, ready } = useApp();
  const [view, setView] = useState<'browser' | 'settings'>('browser');

  return (
    <View style={{ flex: 1, backgroundColor: palette.bg }}>
      <StatusBar style={palette.isDark ? 'light' : 'dark'} />
      {ready ? (
        view === 'browser' ? (
          <BrowserScreen onOpenSettings={() => setView('settings')} />
        ) : (
          <SettingsScreen onBack={() => setView('browser')} />
        )
      ) : null}
      <BusyOverlay />
      <ToastView />
    </View>
  );
}

export default function App() {
  return (
    <SafeAreaProvider>
      <AppProvider>
        <Shell />
      </AppProvider>
    </SafeAreaProvider>
  );
}
